/**
 * Izklaides programmu garākie apraksti (programmas lapā zem ievada).
 * Atstarpe starp rindkopām = tukša rinda. Panelī tos var labot laukā "Apraksts".
 */
const VENUE =
  "Ballīte var notikt Smaidu Darbnīcas telpās Tukumā vai izbraukumā — jūsu mājās, dārzā vai citā svinību vietā. Visu nepieciešamo animators atved līdzi, tāpēc jums atliek tikai svinēt.";

export const programTexts: Record<string, string> = {
  "glitteru-ballite": `Glitteru ballīte ir mirdzoša svētku programma, kurā katrs bērns kļūst par ballītes zvaigzni. Animators katram dalībniekam veido glitteru sejas apgleznojumu un pagaidu tetovējumu pēc paša izvēles, bet krāsainās matu šķipsnas pabeidz svētku tēlu.

Starp skaistumkopšanas brīžiem notiek kustību spēles un konkursi, bet noslēgumā bērni briļļu darbnīcā izgatavo un izrotā savas ballītes brilles, ko paņem līdzi uz mājām.

${VENUE}`,

  "fejas-ballite": `Feju ballītē bērni uz brīdi kļūst par fejām un burvjiem. Vispirms katrs izgatavo savu burvju nūjiņu, bet pēc tam saņem glitteru spīdumus uz sejas, lai būtu gatavs maģiskajam piedzīvojumam.

Ballītes laikā bērni dejo burbuļu mākonī, dodas feju medībās un noslēgumā sacenšas jautrās lidošanas stafetēs. Programmas garums pielāgojas bērnu skaitam — no stundas līdz pusotrai.

${VENUE}`,

  "petnieku-ballite": `Pētnieku ballīte aizved bērnus dinozauru laikmetā. Ar skaņu un gaismas efektiem sākas ekspedīcija, kurā bērni klausās stāstus par dinozauriem, atpazīst dažādas sugas un pārbauda savas zināšanas spēlēs.

Īsti pētnieki arī strādā: bērni saliek dinozaura skeletu, izkaļ un pēta arheologa atradumus, meklē dinozaura olas un piedalās kustību izaicinājumos. Jubilārs saņem savu dinozaura portretu, bet katrs dalībnieks — tematisku tetovējumu.

${VENUE}`,

  "gabbys-dollhouse-ballite": `Gabby's Dollhouse ballītē bērni kopā ar Gabiju dodas ceļojumā pa viņas māju. Ballīte sākas ar iepazīšanos pie kakao un noslēpumainas pārsteiguma kastes atvēršanu, un katrā nākamajā istabā bērnus gaida jauna spēle vai uzdevums.

Programmā ir Gabijas bingo, draudzības rokassprādžu darbnīca un paslēpušos kaķīšu meklēšana. Noslēgumā jubilārs saņem mīkstu kaķīti par piemiņu.

${VENUE}`,

  "spa-ballite": `SPA ballīte ir mierīga un sirsnīga svinēšana bērniem, kuriem patīk rūpēties par sevi. Dalībnieki iepazīst sejas kopšanu ar putiņām, masku un atvēsinošām brillēm, atpūšas relaksācijas brīdī ar gurķu šķēlītēm un ziedūdeni un izbauda roku un pēdu vanniņas.

Ballītes laikā ir arī kakao pauze ar zefīriem, pēdu masāža ar akupunktūras bumbiņām un bižu pīšana. Noslēgumā katrs dalībnieks no dabīgām sastāvdaļām izgatavo savu cukurskrubi un paņem to līdzi.

Ballīti var svinēt Smaidu Darbnīcas telpās vai izbraukumā — abiem variantiem ir savs cenrādis.`,

  "make-up-ballite": `Make-up ballīte ir praktiska meistarklase jaunietēm, kuras vēlas iemācīties rūpēties par savu ādu un veidot ikdienas grimu. Sākumā runājam par sejas kopšanu, iepazīstam kosmētikas produktus, otiņas un to pareizu lietošanu.

Tālāk dalībnieces uzzina, kā izvēlēties krāsas un akcentus atbilstoši sejas formai, un soli pa solim uzklāj ikdienas make-up paši sev. Starplaikā — dzēriens un veselīgi našķi.

Ballīti var svinēt Smaidu Darbnīcas telpās vai izbraukumā — abiem variantiem ir savs cenrādis.`,

  "wednesday-ballite": `Wednesday ballīte ir noslēpumains piedzīvojums drosmīgiem bērniem. Katrs dalībnieks vispirms saņem drosmes dziru, un tad kopā ar Wednesday sākas pārbaudījumi — spēles par baiļu pārvarēšanu, baiļu kaste ar taustes, smaržas un garšas eksperimentiem un skeletu reakcijas spēle.

Ballītē ir arī tematiski eksperimenti, uzdevums tumsā un spēle "Nezināmās rokas", kurā var nopelnīt saldumu cimdiņu. Noslēgumā katrs saņem Wednesday tematikas tetovējumu.

${VENUE}`,

  "frozen-ballite": `Frozen ballīte aizved bērnus Arendellas ziemas pasaulē. Radošajā darbnīcā bērni gatavo kronīšus vai sniegpārsliņas, un tad sākas ledus rotaļas, sniegavīru stafetes un ledus kristālu meklēšana.

Ballītes kulminācija ir tikšanās ar Elzu — ar pārsteigumiem un stāstu par draudzību un drosmi, bet noslēgumā visi kopā dodas ceļojumā uz Arendellu.

${VENUE}`,

  "slaima-meistarklase": `Slaima meistarklasē katrs dalībnieks soli pa solim izgatavo savu slaimu. Bērni paši izvēlas krāsu, pievieno spīdumus un dekorācijas, tāpēc katrs slaims sanāk atšķirīgs.

Meistarklases laikā notiek arī jautras spēles, bet noslēgumā katrs iepako savu slaimu un paņem to līdzi uz mājām.

${VENUE}`,

  "eksperimentu-ballite": `Eksperimentu ballītē zinātne kļūst par piedzīvojumu. Bērni ne tikai vēro, bet paši piedalās eksperimentos — ar krāsām, pārsteidzošām reakcijām un dabas likumiem, kurus var pārbaudīt savām rokām.

Katrs dalībnieks kļūst par mazo zinātnieku, bet programmas noslēgumā visi kopā veic lielo, iespaidīgo noslēguma eksperimentu.

${VENUE}`,

  "putu-ballite": `Putu ballīte ir viena no jautrākajām aktivitātēm svētkos. Ar putu lielgabalu radām putu kalnus, kuros bērni (un arī pieaugušie) var skraidīt, lēkāt un rotaļāties.

Piedāvājam 30 minūšu putu ballīti ģimenes svinībām un 60 minūšu programmu uzņēmumu un publiskiem pasākumiem. Pēc putu ražošanas beigām bērni var turpināt rotaļāties putās. Pakalpojums pieejams visā Latvijā; ceļa izdevumi — 0,30 €/km.`,

  "nerf-ballite": `Nerf ballīte ir aktīva komandu spēle zēniem un meitenēm, kuriem patīk kustība un sacensības. Pēc iesildīšanās dalībnieki dod komandas zvērestu, iegūst kamuflāžas izskatu un meklē savu Nerf aprīkojumu.

Tālāk seko komandu spēles, uzdevumi un precizitātes pārbaudījumi, bet ballīte noslēdzas ar fināla misiju visiem dalībniekiem.

${VENUE}`,

  "parsteiguma-tels": `Pārsteiguma tēls ir īsa, bet spilgta vizīte, kas padara svētkus neaizmirstamus. Tēls negaidīti ierodas jūsu svinībās, dejo kopā ar gaviļnieku un viesiem un fotografējas ar visiem, kas vēlas.

Vizīte ilgst līdz 15 minūtēm, un to var pieteikt dzimšanas dienām, ģimenes svētkiem un citiem pasākumiem.`,

  "sejas-apgleznosana": `Sejas apgleznošana ir iecienīta aktivitāte gan bērniem, gan pieaugušajiem. Piedāvājam plašu dizainu izvēli — dzīvniekus, pasaku tēlus, taureņus, princeses, supervaroņus un festivālu grimu.

Papildus var izvēlēties glittera tetovējumus, kas ir noturīgi un krāsaini. Pakalpojums pieejams privātām svinībām, uzņēmumu un publiskiem pasākumiem visā Latvijā.`,

  "piratu-ballite": `Pirātu ballītē ikviens dalībnieks kļūst par drosmīgas pirātu komandas daļu. Vispirms izvēlamies kuģa kapteini un piešķiram viņam īstu pirāta vārdu, bet tad komanda iziet veiklības un attapības pārbaudījumus.

Pirāti lasa dārgumu karti un meklē apslēpto dārgumu, zobenu darbnīcā katrs izgatavo savu pirāta zobenu, un noslēgumā lielais pirātu izaicinājums parāda, vai komanda ir gatava iekarot jūras.

${VENUE}`,
};
