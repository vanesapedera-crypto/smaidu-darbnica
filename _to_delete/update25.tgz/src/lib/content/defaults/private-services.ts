import type { Service } from "../types";
import { programs } from "./programs-legacy";
import { programTexts } from "./program-texts";

/**
 * Bērnu ballīšu programmas (privātpersonām).
 * Saturs pārņemts no iepriekšējās versijas (programs-legacy.ts) un pārveidots
 * vienotajā Service formātā, lai to varētu glabāt un rediģēt `services` tabulā.
 */

// Noņem emocijzīmes no virsrakstiem — jaunajā dizainā tās aizstāj ikonas
const stripEmoji = (s: string) =>
  s.replace(/[\p{Extended_Pictographic}️‍]/gu, "").trim();

export const privateServices: Service[] = programs.map((p, i) => ({
  slug: p.slug,
  audience: "private",
  title: p.title,
  excerpt: p.shortDescription,
  intro: p.description || p.shortDescription,
  body: programTexts[p.slug] ?? "",
  highlights: [],
  suitableFor: [],
  activities: p.activities.map((a) => ({
    title: stripEmoji(a.title),
    description: a.description,
  })),
  pricing: p.pricing,
  pricingNote:
    p.note ??
    "Izbraukuma ballītēm ceļa izdevumi tiek aprēķināti atkarībā no pasākuma norises vietas.",
  faq: [],
  age: p.age,
  duration: p.duration,
  participants: "",
  icon: "PartyPopper",
  heroImage: `/media/${p.slug}/${p.slug}-01.webp`,
  albums: [p.slug],
  seasons: [],
  sort: (i + 1) * 10,
  published: true,
  seoTitle: "",
  seoDescription: "",
}));
