import PhotoReel from "@/components/site/PhotoReel";
import ServiceCard from "@/components/site/ServiceCard";
import Tabs from "@/components/site/Tabs";
import { CtaBand } from "@/components/site/sections";
import { StageHeading, StageHero } from "@/components/site/stage";
import { ButtonLink, Container, Section } from "@/components/site/ui";
import { toReel } from "@/lib/content/media";
import { getCategoryImages, getServices, getSettings } from "@/lib/content/queries";
import type { Service } from "@/lib/content/types";
import { pageMetadata } from "@/lib/seo";

export const revalidate = 3600;

export function generateMetadata() {
  return pageMetadata({
    path: "/uznemumiem",
    title: "Pasākumi uzņēmumiem un pašvaldībām",
    description:
      "Ziemassvētku un vasaras piedāvājumi uzņēmumiem: izrādes, radošās darbnīcas, lielformāta spēles, burbuļu šovi, komandas saliedēšana un bērnu zonas visā Latvijā.",
  });
}

// Fotolentei — uzņēmumu, pilsētu un sezonas pasākumi
const CATEGORIES = ["uznemumu-pasakumi", "pilsetu-svetki", "ziemassvetki", "lielformata-speles", "bernu-zona"];

/** Pakalpojumu kartīšu režģis (viena sezona). */
function Cards({ items }: { items: Service[] }) {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((s, i) => (
        <ServiceCard key={s.slug} service={s} href={`/uznemumiem/${s.slug}`} index={i} />
      ))}
    </div>
  );
}

export default async function BusinessPage() {
  const [services, settings, photos] = await Promise.all([
    getServices("business"),
    getSettings(),
    getCategoryImages(CATEGORIES, 18),
  ]);
  const { business, contact } = settings;

  // Sezonas nosaka panelī (Pakalpojumi → "Sezona"); viens pakalpojums var būt vairākās
  // Pakalpojums bez norādītas sezonas tiek rādīts sadaļā "Visu gadu"
  const bySeason = (season: string) =>
    services.filter((s) => (s.seasons.length > 0 ? s.seasons : ["visu-gadu"]).includes(season));
  const winter = bySeason("ziema");
  const summer = bySeason("vasara");
  const allYear = bySeason("visu-gadu");

  // Sezonu secība mainās automātiski: oktobrī–janvārī pirmie Ziemassvētki, pārējā gadā — vasara
  const month = new Date().getMonth(); // 0 = janvāris
  const winterFirst = month >= 9 || month === 0;

  // Cilnes: pašreizējā sezona pirmā; tukšas cilnes nerāda
  const panel = (text: string, items: Service[]) => (
    <>
      <p className="mb-10 max-w-2xl text-lg leading-8 text-ink-soft">{text}</p>
      <Cards items={items} />
    </>
  );
  const seasonTabs = [
    { id: "ziemassvetki", label: "Ziemassvētki", content: panel(business.winterText, winter), n: winter.length },
    { id: "vasara", label: "Vasara", content: panel(business.summerText, summer), n: summer.length },
  ];
  const tabs = [
    ...(winterFirst ? seasonTabs : [...seasonTabs].reverse()),
    { id: "visu-gadu", label: "Visu gadu", content: panel(business.allYearText, allYear), n: allYear.length },
  ]
    .filter((t) => t.n > 0)
    .map(({ id, label, content }) => ({ id, label, content }));

  return (
    <>
      <StageHero
        eyebrow="Uzņēmumiem · pašvaldībām · skolām"
        title={business.heroTitle}
        highlight={business.heroHighlight}
        text={business.heroText}
        crumbs={[{ name: "Uzņēmumiem", path: "/uznemumiem" }]}
        photos={[
          { src: "/media/vizium-jubileja/vizium-jubileja-09.webp", caption: "Burbuļu šovs" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-03.webp", caption: "Ziemassvētku izrāde" },
          { src: "/media/stiga-meza-dienas/stiga-meza-dienas-02.webp", caption: "Sporta spēles" },
        ]}
      >
        <ButtonLink href="/kontakti#pieprasijums" size="lg" variant="dark" arrow>
          Pieprasīt piedāvājumu
        </ButtonLink>
        <ButtonLink href={`#${tabs[0]?.id ?? "piedavajumi"}`} size="lg" variant="outlineDark">
          {winterFirst && winter.length > 0 ? "Ziemassvētku piedāvājumi" : "Vasaras piedāvājumi"}
        </ButtonLink>
      </StageHero>

      {/* Piedāvājumi pa sezonām — cilnēs, lai lapa nebūtu gara */}
      <Section id="piedavajumi" className="scroll-mt-20">
        <Container>
          <StageHeading eyebrow="Piedāvājumi" title="Ko varam" highlight="piedāvāt" className="mb-10" />
          <Tabs tabs={tabs} defaultTab={tabs[0]?.id} />
        </Container>
      </Section>

      {photos.length > 0 && (
        <section className="overflow-hidden bg-surface pt-20 pb-12 md:pt-28">
          <Container>
            <StageHeading eyebrow="Foto" title={business.photosTitle} />
          </Container>
          <PhotoReel images={toReel(photos)} />
        </section>
      )}

      <CtaBand
        title="Plānojat pasākumu?"
        text="Pastāstiet par savu ideju — ieteiksim piemērotāko programmu un sagatavosim piedāvājumu."
        contact={contact}
      />
    </>
  );
}
