import type { Service } from "../types";

/**
 * Pakalpojumi uzņēmumiem un pašvaldībām (noklusējuma saturs / seed).
 * Astoņi konkrēti piedāvājumi; "izrades" kartīte ved uz lapu /izrades.
 * Tekstus var labot administrēšanas panelī sadaļā "Pakalpojumi".
 */

type Draft = Omit<
  Service,
  "audience" | "pricing" | "published" | "age" | "seoTitle" | "seoDescription"
> & Partial<Pick<Service, "pricing" | "age">>;

const INDIVIDUAL =
  "Cena atkarīga no dalībnieku skaita, ilguma un norises vietas. Sagatavosim individuālu piedāvājumu vienas darba dienas laikā.";

const drafts: Draft[] = [
  {
    slug: "lielformata-speles",
    title: "Lielformāta spēles",
    icon: "Dices",
    excerpt:
      "Party Trip ir lielformāta spēļu programma, kuru pielāgojam katra pasākuma vajadzībām, auditorijai un mērķim. Mēs nodrošinām visu pasākuma norisi — no spēļu uzstādīšanas un vadīšanas līdz punktu skaitīšanai un uzvarētāju paziņošanai.",
    intro: "", // ievads jau ir galvenē (excerpt)
    body: "",
    highlights: [],
    suitableFor: ["Uzņēmumu pasākumi", "Komandu sacensības", "Pilsētu svētki un festivāli", "Ģimenes un sporta dienas"],
    // Īsi — ko mēs nodrošinām (lapā rāda kā kompaktu joslu virs spēlēm)
    activities: [
      { title: "Spēļu izvēle", description: "Kopā ar jums izvēlamies pasākumam piemērotāko spēļu kombināciju." },
      { title: "Uzstādīšana", description: "Atvedam un uzstādām spēles pasākuma vietā — telpās vai brīvā dabā." },
      { title: "Vadīšana un punkti", description: "Mūsu vadītāji skaidro noteikumus, vada spēles un skaita punktus." },
      { title: "Uzvarētāju paziņošana", description: "Noslēgumā apkopojam rezultātus un paziņojam uzvarētājus." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai spēles der komandu sacensībām?", answer: "Jā — mūsu vadītāji vada spēles, skaita punktus un noslēgumā paziņo uzvarētājus." },
      { question: "Vai varam izvēlēties konkrētas spēles?", answer: "Jā. Kopā izveidojam spēļu kombināciju, kas der jūsu vietai, dalībnieku skaitam un pasākuma mērķim." },
    ],
    duration: "", // saskaņojam ar klientu
    participants: "", // saskaņojam ar klientu
    heroImage: "/media/lielformata-speles/lielformata-speles-01.webp",
    albums: ["lielformata-speles", "vimbu-svetki-2026", "bauska-taste-2024"],
    seasons: ["visu-gadu"],
    sort: 10,
  },
  {
    slug: "radosas-darbnicas",
    title: "Radošās darbnīcas",
    icon: "Palette",
    excerpt:
      "Radošās darbnīcas bērniem un pieaugušajiem — dalībnieki paši izgatavo suvenīru, ko paņemt līdzi.",
    intro:
      "Radošās darbnīcas ir lielisks veids, kā pasākumā iesaistīt apmeklētājus un dāvāt viņiem paliekošu atmiņu. Tematiku pielāgojam sezonai, pasākumam vai jūsu zīmolam.",
    body:
      "Mēs atvedam visus materiālus, instrumentus un darbnīcu vadītājus. Darbnīcas var notikt nepārtraukti visu pasākuma laiku — apmeklētāji pienāk, izgatavo savu darbu un dodas tālāk.\n\nPopulārākās tēmas: sezonālie rotājumi, burvju nūjiņas, rokassprādzes, dabas materiālu darbi, slaims un svētku kartītes.",
    highlights: [
      "Visi materiāli iekļauti",
      "Tematika pēc pasākuma vai zīmola",
      "Piemērots plūsmas pasākumiem",
      "Suvenīrs katram dalībniekam",
    ],
    suitableFor: ["Pilsētu svētki un festivāli", "Uzņēmumu ģimenes dienas", "Klientu dienas", "Skolas pasākumi"],
    activities: [
      { title: "Sezonālie rotājumi", description: "Ziemassvētku, Lieldienu vai vasaras tēmas darbi." },
      { title: "Dabas materiāli", description: "Darbi no koka, sūnām, ziediem un citiem dabas materiāliem." },
      { title: "Rotaslietas", description: "Rokassprādzes, kaklarotas un matu rotas." },
      { title: "Slaims un eksperimenti", description: "Krāsainais slaims un vienkārši zinātnes eksperimenti." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik cilvēku var piedalīties vienlaikus?", answer: "Parasti 10–20 pie viena galda, bet varam iekārtot vairākas darbnīcu vietas." },
    ],
    duration: "", // saskaņojam ar klientu
    participants: "", // saskaņojam ar klientu
    heroImage: "/media/valpurgu-nakts-tervete-2026/valpurgu-nakts-tervete-2026-13.webp",
    albums: ["valpurgu-nakts-tervete-2026", "ziemassvetki-2025", "stiga-meza-dienas"],
    seasons: ["visu-gadu"],
    sort: 20,
  },
  {
    slug: "pasakumu-organizesana",
    title: "Pasākumu vadīšana un organizēšana",
    icon: "Building2",
    excerpt:
      "Pasākuma organizēšana un vadīšana no idejas līdz noslēgumam — scenārijs, vadītājs, programma un viss nepieciešamais.",
    intro:
      "Uzņēmuma jubileja, jauna biroja atklāšana, klientu diena vai zīmola festivāls — jums ir viens kontakts, kas koordinē visu pasākumu.",
    body: "",
    highlights: [],
    suitableFor: ["Uzņēmumu jubilejas", "Klientu un partneru dienas", "Zīmola festivāli", "Atvēršanas svētki"],
    activities: [
      { title: "Koncepcija", description: "Kopā definējam mērķi, auditoriju un pasākuma noskaņu." },
      { title: "Programma", description: "Izveidojam dienas plānu ar šoviem, aktivitātēm un pauzēm." },
      { title: "Norise", description: "Mūsu komanda vada pasākumu, jūs baudāt svētkus kopā ar viesiem." },
      { title: "Noslēgums", description: "Sakārtojam vietu un pēc vēlēšanās nododam foto materiālus." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik laicīgi jāpiesaka pasākums?", answer: "Ieteicams 3–6 nedēļas iepriekš, sezonas laikā (jūnijs, decembris) — agrāk." },
      { question: "Vai varat strādāt ar mūsu zīmolu?", answer: "Jā, dekorācijas, foto stūri un aktivitātes var veidot jūsu zīmola krāsās un tematikā." },
      { question: "Vai izrakstāt rēķinu uzņēmumam?", answer: "Jā, strādājam ar līgumu un rēķinu juridiskai personai." },
    ],
    duration: "", // saskaņojam ar klientu
    participants: "", // saskaņojam ar klientu
    heroImage: "/media/vizium-jubileja/vizium-jubileja-07.webp",
    albums: ["vizium-jubileja", "elyndi-fest-2026", "bauska-taste-2024", "bauska-taste-2022"],
    seasons: ["visu-gadu"],
    sort: 30,
  },
  {
    slug: "mazulu-zona",
    title: "Mazuļu zona",
    icon: "Baby",
    excerpt:
      "Droša un aprīkota bērnu zona ar animatoriem, lai vecāki var mierīgi baudīt pasākumu.",
    intro:
      "Kad pasākumā ir bērni, vecāki vēlas zināt, ka viņu atvases ir drošās rokās. Mēs iekārtojam bērnu zonu ar aktivitātēm, rotaļām un pieredzējušiem animatoriem.",
    body:
      "Bērnu zonu veidojam atbilstoši bērnu vecumam: mazuļiem — mīkstie moduļi un rotaļu stūrītis, lielākiem bērniem — spēles, radošās darbnīcas, sejas apgleznošana un tematiskie tēli.\n\nAnimatoru skaitu plānojam pēc bērnu skaita, lai katrs bērns būtu pieskatīts.",
    highlights: [
      "Pieredzējuši animatori",
      "Mazuļu stūrītis ar mīkstajiem moduļiem",
      "Aktivitātes dažādiem vecumiem",
      "Darbojas visu pasākuma laiku",
    ],
    suitableFor: ["Uzņēmumu svētki", "Konferences un semināri", "Kāzas un banketi", "Festivāli"],
    activities: [
      { title: "Mazuļu stūrītis", description: "Mīkstie moduļi un rotaļlietas bērniem līdz 3 gadiem." },
      { title: "Spēles un rotaļas", description: "Kustību spēles un konkursi animatoru vadībā." },
      { title: "Radošais stūrītis", description: "Zīmēšana, darbnīcas un sejas apgleznošana." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai bērni tiek pieskatīti?", answer: "Jā, bērnu zonā vienmēr ir mūsu animatori. Animatoru skaitu plānojam pēc bērnu skaita un vecuma." },
    ],
    duration: "", // saskaņojam ar klientu
    participants: "", // saskaņojam ar klientu
    heroImage: "/media/mazulu-sturitis/mazulu-sturitis-01.webp",
    albums: ["mazulu-sturitis", "bauska-taste-2022", "tukuma-rozu-svetki-2025"],
    seasons: ["visu-gadu"],
    sort: 40,
  },
  {
    slug: "sejas-apgleznosana",
    title: "Sejas apgleznošana",
    icon: "Brush",
    excerpt:
      "Profesionāla seju apgleznošana un glitteru tetovējumi pasākumiem — ātri, krāsaini un ar drošām kosmētiskajām krāsām.",
    intro:
      "Seju apgleznošana ir viena no pieprasītākajām aktivitātēm jebkurā pasākumā. Mūsu mākslinieki strādā ātri, tāpēc rindas ir īsas, bet zīmējumi — krāsaini un precīzi.",
    body:
      "Izmantojam sertificētas kosmētiskās krāsas un glitterus, kas ir droši bērnu ādai. Dizainus pielāgojam pasākuma tēmai — no tauriņiem un supervaroņiem līdz jūsu zīmola krāsām un festivāla stilam.\n\nLieliem pasākumiem nodrošinām vairākus māksliniekus vienlaikus.",
    highlights: [
      "Droša, sertificēta kosmētika",
      "Dizaini bērniem un pieaugušajiem",
      "Glitteru tetovējumi un matu šķipsnas",
      "Vairāki mākslinieki lieliem pasākumiem",
    ],
    suitableFor: ["Festivāli", "Uzņēmumu ģimenes dienas", "Pilsētu svētki", "Sporta pasākumi"],
    activities: [
      { title: "Sejas apgleznošana", description: "Klasiski un tematiski dizaini." },
      { title: "Glitteru tetovējumi", description: "Pagaidu tetovējumi ar kosmētisko glitteru." },
      { title: "Festivālu dizaini", description: "Glitteri un akcenti pieaugušajiem." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik cilvēkus var apgleznot stundā?", answer: "Tas atkarīgs no dizainu sarežģītības. Mākslinieku skaitu un laiku saskaņojam ar jums pēc apmeklētāju skaita." },
    ],
    duration: "", // saskaņojam ar klientu
    participants: "", // saskaņojam ar klientu
    heroImage: "/media/tukuma-rozu-svetki-2025/tukuma-rozu-svetki-2025-07.webp",
    albums: ["sejas-apgleznosana", "tukuma-rozu-svetki-2025", "dobeles-pilsetas-svetki-2026"],
    seasons: ["visu-gadu"],
    sort: 50,
  },
  {
    slug: "putu-ballite",
    title: "Putu ballīte",
    icon: "Sparkles",
    excerpt:
      "Putu ballītes noma uzņēmumu, sabiedriskiem un ģimenes pasākumiem — aktīva ballīte putās ar mūziku.",
    intro:
      "Putu ballīte ir jautrs un aktīvs piedzīvojums bērniem un pieaugušajiem — lielisks noslēgums vasaras svētkiem, ģimenes dienām un festivāliem.",
    body:
      "**Ģimenes pasākumam:** 30 minūtes aktīva putu ballīte + kamēr putas izzudīs (kopā ballīte putās līdz 1 h).\n\n**Sabiedriskiem un korporatīviem pasākumiem:** 60 minūtes aktīva putu ballīte + kamēr putas izzudīs (kopā ballīte putās līdz 1,5 h).",
    highlights: [],
    suitableFor: ["Uzņēmumu ģimenes dienas", "Pilsētu svētki", "Festivāli", "Ģimenes svētki"],
    activities: [],
    // Cenas no vecās lapas
    pricing: [
      {
        title: "Ģimenes pasākumam",
        options: [
          { label: "Putu ballīte 30 minūtes", price: 180 },
          { label: "Ceļa izdevumi (€/km)", price: 0.3 },
        ],
      },
      {
        title: "Sabiedriskiem un korporatīviem pasākumiem",
        options: [
          { label: "Putu ballīte 60 minūtes, sākot no (+ PVN)", price: 400 },
          { label: "Ceļa izdevumi (€/km)", price: 0.3 },
        ],
      },
    ],
    pricingNote: "",
    faq: [],
    duration: "",
    participants: "",
    heroImage: "/media/putu-ballite/putu-ballite-01.webp",
    albums: ["putu-ballite"],
    seasons: ["visu-gadu"],
    sort: 60,
  },
  {
    slug: "sporta-speles",
    title: "Sporta spēles uzņēmumiem",
    icon: "Trophy",
    excerpt:
      "Sporta dienas un aktīvas stafetes uzņēmumiem, skolām un pašvaldībām — ar tiesnešiem, inventāru un apbalvošanu.",
    intro:
      "Kustība, azarts un veselīga sacensība. Organizējam sporta spēles, kurās var piedalīties ikviens neatkarīgi no fiziskās sagatavotības.",
    body:
      "Sagatavojam disciplīnu programmu, nodrošinām inventāru, vadītājus un rezultātu uzskaiti. Disciplīnas izvēlamies tā, lai tās būtu jautras un drošas, nevis tikai spēka pārbaude.\n\nSporta spēles lieliski der uzņēmuma vasaras sporta dienai, skolas pasākumam vai pagasta svētkiem, un tās var papildināt ar bērnu zonu ģimenēm.",
    highlights: [
      "Disciplīnas visām vecuma grupām",
      "Inventārs un tiesneši",
      "Rezultātu uzskaite un apbalvošana",
      "Iespēja pievienot bērnu zonu",
    ],
    suitableFor: ["Uzņēmumu sporta dienas", "Skolas un bērnudārzi", "Pagastu un novadu svētki", "Ģimenes dienas"],
    activities: [
      { title: "Komandu stafetes", description: "Klasiskas un netradicionālas stafetes ar jautriem uzdevumiem." },
      { title: "Veiklības disciplīnas", description: "Koka kājas, mešana mērķī, līdzsvara un precizitātes uzdevumi." },
      { title: "Lielformāta spēles", description: "Milzu spēles, kas piesaista gan bērnus, gan pieaugušos." },
      { title: "Apbalvošana", description: "Medaļas, diplomi un uzvarētāju foto." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai jānodrošina inventārs?", answer: "Nē, visu nepieciešamo inventāru atvedam paši." },
      { question: "Cik dalībnieku var piedalīties?", answer: "Dalībnieku skaitu saskaņojam ar jums — programmu pielāgojam gan nelielām komandām, gan lieliem kolektīviem." },
    ],
    duration: "", // saskaņojam ar klientu
    participants: "", // saskaņojam ar klientu
    heroImage: "/media/stiga-meza-dienas/stiga-meza-dienas-02.webp",
    albums: ["stiga-meza-dienas", "lielformata-speles", "vimbu-svetki-2026"],
    seasons: ["visu-gadu"],
    sort: 70,
  },
  {
    slug: "izrades",
    title: "Izrādes",
    icon: "Drama",
    excerpt:
      "Ziemassvētku izrādes visai ģimenei — “Ziemassvētku faktors”, “Dāvanu prieks” un “Dāvanu recepte”. Noskatieties video.",
    intro:
      "Ziemassvētku izrādes visai ģimenei uzņēmumu, pašvaldību un kultūras centru pasākumiem.",
    body: "",
    highlights: [],
    suitableFor: ["Uzņēmumu svētki", "Pašvaldību pasākumi", "Kultūras centri"],
    activities: [],
    pricingNote: INDIVIDUAL,
    faq: [],
    duration: "",
    participants: "",
    heroImage: "/media/ziemassvetki-2025/ziemassvetki-2025-03.webp",
    albums: ["ziemassvetki-2025"],
    seasons: ["visu-gadu"],
    sort: 80,
  },
];

export const businessServices: Service[] = drafts.map((d) => ({
  audience: "business",
  pricing: [],
  age: "Visiem vecumiem",
  published: true,
  seoTitle: "",
  seoDescription: "",
  ...d,
}));
