"use client";

import { useState } from "react";
import { Clock, Play } from "lucide-react";
import RichText from "./RichText";
import type { Video } from "@/lib/content/types";

/** YouTube / Vimeo saites atpazīšana. */
function parse(src: string): { kind: "youtube" | "vimeo" | "file"; id?: string } {
  const yt = src.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
  if (yt) return { kind: "youtube", id: yt[1] };
  const vimeo = src.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vimeo) return { kind: "vimeo", id: vimeo[1] };
  return { kind: "file" };
}

/**
 * Izrāžu saraksts: katrai izrādei video + nosaukums, fakti un apraksts.
 * Rindas mijas (video pa kreisi / pa labi), lai lapa nebūtu vienveidīga.
 * YouTube/Vimeo atskaņotājs tiek ielādēts tikai pēc klikšķa (līdz tam — vāciņa attēls).
 */
export default function VideoShowcase({ videos, bookHref = [] }: { videos: Video[]; /** Rezervācijas saite katrai izrādei */ bookHref?: string[] }) {
  return (
    <ol className="space-y-20 md:space-y-28">
      {videos.map((v, i) => {
        const facts = [
          v.duration && { icon: Clock, label: "Ilgums", value: v.duration },
        ].filter(Boolean) as { icon: typeof Clock; label: string; value: string }[];

        return (
          <li
            key={`${v.src}-${i}`}
            data-reveal
            className="mx-auto grid max-w-2xl grid-cols-1 items-center gap-8 md:items-start md:max-w-none md:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] md:gap-10 lg:gap-14"
          >
            <div className={i % 2 === 1 ? "md:sticky md:top-28 md:order-2" : "md:sticky md:top-28"}>
              <VideoCard video={v} />
            </div>
            <div className={i % 2 === 1 ? "md:order-1" : ""}>
              <p aria-hidden className="font-display text-5xl leading-none font-extrabold text-ink opacity-[0.12] md:text-6xl">
                {String(i + 1).padStart(2, "0")}
              </p>
              <h3 className="display mt-3 text-2xl md:text-3xl">{v.title}</h3>
              {v.description && <RichText text={v.description} className="prose-sd mt-5 text-ink-soft" />}
              <dl className="mt-7 flex flex-wrap gap-3">
                {facts.map(({ icon: Icon, label, value }) => (
                  <div key={label} className="rounded-2xl bg-surface px-4 py-3">
                    <dt className="flex items-center gap-1.5 text-xs font-extrabold tracking-[0.08em] text-ink-soft uppercase">
                      <Icon className="size-3.5" aria-hidden />
                      {label}
                    </dt>
                    <dd className="mt-1 text-sm font-bold">{value}</dd>
                  </div>
                ))}
              </dl>
              <a
                href={bookHref[i] ?? "/kontakti#pieprasijums"}
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-extrabold text-white transition-transform hover:-translate-y-0.5"
              >
                Rezervēt izrādi <span aria-hidden>→</span>
              </a>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function VideoCard({ video }: { video: Video }) {
  const [playing, setPlaying] = useState(false);
  const { kind, id } = parse(video.src);
  // YouTube vāciņš: vispirms 1280×720 (maxres); ja tāda nav, krītam uz 640×480 (sd) un 480×360 (hq)
  const ytSizes = ["maxresdefault", "sddefault", "hqdefault"];
  const [ytSize, setYtSize] = useState(0);
  const poster = video.poster || (kind === "youtube" ? `https://i.ytimg.com/vi/${id}/${ytSizes[ytSize]}.jpg` : "");

  const frame = "relative aspect-video overflow-hidden rounded-[22px] bg-ink shadow-[0_30px_50px_-28px_rgba(31,41,55,0.6)]";

  if (kind === "file") {
    return (
      <div className={frame}>
        <video src={video.src} poster={poster || undefined} controls preload="none" playsInline className="size-full object-cover">
          <track kind="captions" />
        </video>
      </div>
    );
  }

  if (playing) {
    const url =
      kind === "youtube"
        ? `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`
        : `https://player.vimeo.com/video/${id}?autoplay=1`;
    return (
      <div className={frame}>
        <iframe
          src={url}
          title={video.title}
          allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
          allowFullScreen
          className="absolute inset-0 size-full border-0"
        />
      </div>
    );
  }

  return (
    <button type="button" onClick={() => setPlaying(true)} aria-label={`Atskaņot: ${video.title}`} className={`${frame} group block w-full`}>
      {poster && (
        // eslint-disable-next-line @next/next/no-img-element -- ārēja vāciņa bilde (YouTube)
        <img
          src={poster}
          alt=""
          loading="lazy"
          onLoad={(e) => {
            // YouTube "nav attēla" gadījumā atgriež 120×90 pelēku bildi — tad ņemam nākamo izmēru
            if (!video.poster && kind === "youtube" && e.currentTarget.naturalWidth <= 120 && ytSize < ytSizes.length - 1) setYtSize(ytSize + 1);
          }}
          onError={() => !video.poster && ytSize < ytSizes.length - 1 && setYtSize(ytSize + 1)}
          className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.03]" />
      )}
      <span className="absolute inset-0 grid place-items-center">
        <span className="grid size-20 place-items-center rounded-full bg-brand text-ink shadow-xl transition-transform group-hover:scale-110">
          <Play className="ml-1 size-8 fill-ink" aria-hidden />
        </span>
      </span>
    </button>
  );
}
