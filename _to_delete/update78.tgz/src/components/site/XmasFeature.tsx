import Link from "next/link";
import type { HomeSettings } from "@/lib/content/types";
import Photo from "./Photo";
import { PhotoStack } from "./stage";
import { ButtonLink, Container } from "./ui";

/*
 * Ziemassvētku sezonas bloki. Ieslēdz/izslēdz panelī (Sākumlapa → "Rādīt Ziemassvētku reklāmu").
 *  - XmasBanner: neliela reklāma sākumlapā
 *  - XmasFeature: pilns bloks lapā "Uzņēmumiem" ar Ziemassvētku piedāvājumiem
 */

// Zvaigžņu "sniegs" — tikai CSS, bez attēliem
const stars = {
  backgroundImage:
    "radial-gradient(circle at 12% 18%, var(--brand) 0 2px, transparent 3px), radial-gradient(circle at 78% 12%, #fff 0 1.5px, transparent 2.5px), radial-gradient(circle at 42% 72%, #fff 0 1.5px, transparent 2.5px), radial-gradient(circle at 90% 64%, var(--brand) 0 2px, transparent 3px), radial-gradient(circle at 26% 88%, #fff 0 1px, transparent 2px), radial-gradient(circle at 60% 30%, #fff 0 1px, transparent 2px)",
  backgroundSize: "340px 340px",
};

export function XmasBanner({ home }: { home: HomeSettings }) {
  if (!home.xmasEnabled) return null;
  const photo = home.xmasPhotos[0];

  return (
    <section aria-label={home.xmasEyebrow} className="py-12 md:py-16">
      <Container>
        <Link
          href="/uznemumiem#ziemassvetki"
          data-reveal
          className="group relative isolate grid grid-cols-1 items-center gap-6 overflow-hidden rounded-[2rem] bg-ink p-6 text-white sm:grid-cols-[minmax(0,1fr)_auto] sm:p-8 md:grid-cols-[180px_minmax(0,1fr)_auto] md:gap-8 md:p-10"
        >
          <div aria-hidden className="absolute inset-0 -z-10 opacity-60" style={stars} />
          {photo && (
            <div className="relative hidden aspect-square w-[180px] -rotate-3 overflow-hidden rounded-2xl border-[6px] border-white transition-transform duration-500 group-hover:rotate-0 md:block">
              <Photo src={photo.src} alt={photo.caption} fill sizes="180px" className="object-cover" />
            </div>
          )}
          <div className="min-w-0">
            <p className="inline-flex rounded-full bg-brand px-3.5 py-1 text-xs font-extrabold tracking-[0.12em] text-ink uppercase">
              ✦ {home.xmasEyebrow}
            </p>
            <h2 className="display mt-4 text-2xl sm:text-3xl md:text-4xl">
              {home.xmasTitle} {home.xmasHighlight && <span className="sticker-light">{home.xmasHighlight}</span>}
            </h2>
            <p className="mt-3 max-w-2xl leading-7 text-white/80">{home.xmasShort}</p>
          </div>
          <span className="inline-flex h-14 items-center justify-center gap-2 rounded-full bg-brand px-7 font-extrabold whitespace-nowrap text-ink transition-transform group-hover:translate-x-1">
            Ziemassvētku piedāvājumi →
          </span>
        </Link>
      </Container>
    </section>
  );
}

export function XmasFeature({ home, children }: { home: HomeSettings; children?: React.ReactNode }) {
  if (!home.xmasEnabled) return null;

  return (
    <section id="ziemassvetki" aria-labelledby="ziemassvetki-virsraksts" className="relative isolate scroll-mt-20 overflow-hidden bg-ink py-20 text-white md:py-28">
      <div aria-hidden className="absolute inset-0 -z-10 opacity-60" style={stars} />
      <span aria-hidden className="absolute -top-10 -left-6 -z-10 font-display text-[16rem] leading-none text-brand/10 md:text-[22rem]">
        ✦
      </span>

      <Container className="grid grid-cols-1 items-center gap-14 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-12">
        <div data-reveal>
          <p className="inline-flex rounded-full bg-brand px-4 py-1.5 text-xs font-extrabold tracking-[0.12em] text-ink uppercase">
            {home.xmasEyebrow}
          </p>
          <h2 id="ziemassvetki-virsraksts" className="display mt-6 text-4xl sm:text-5xl lg:text-6xl">
            Ziemassvētku <span className="sticker-light">piedāvājumi</span>
          </h2>
          <p className="mt-6 max-w-xl text-lg leading-8 text-white/80">{home.xmasText}</p>

          {home.xmasPoints.length > 0 && (
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {home.xmasPoints.map((p) => (
                <li key={p} className="flex items-start gap-3 font-semibold">
                  <span aria-hidden className="text-brand">
                    ✦
                  </span>
                  {p}
                </li>
              ))}
            </ul>
          )}

          <div className="mt-10 flex flex-wrap gap-3">
            <ButtonLink href="/kontakti?pakalpojums=izrades#pieprasijums" size="lg" arrow>
              Pieprasīt piedāvājumu
            </ButtonLink>
            <ButtonLink href="/izrades" size="lg" variant="ghostLight">
              Ziemassvētku izrādes
            </ButtonLink>
          </div>
        </div>

        {home.xmasPhotos.length > 0 && <PhotoStack photos={home.xmasPhotos} />}
      </Container>

      {children && <Container className="mt-16 md:mt-20">{children}</Container>}
    </section>
  );
}
