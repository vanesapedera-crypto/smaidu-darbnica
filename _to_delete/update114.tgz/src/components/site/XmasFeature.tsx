import Link from "next/link";
import type { HomeSettings, Service } from "@/lib/content/types";
import { businessHref } from "@/lib/utils";
import Photo from "./Photo";
import ServiceCard from "./ServiceCard";
import { ButtonLink, Container } from "./ui";

/*
 * Ziemassvētku sezonas bloki. Ieslēdz/izslēdz panelī (Sākumlapa → "Rādīt Ziemassvētku reklāmu").
 *  - XmasBanner: neliela reklāma sākumlapā
 *  - XmasFeature: pilns bloks lapā "Uzņēmumiem" ar Ziemassvētku piedāvājumiem
 */

// Zvaigžņu "sniegs" — tikai CSS, bez attēliem
const stars = {
  backgroundImage:
    "radial-gradient(circle at 12% 18%, var(--brand) 0 2px, transparent 3px), radial-gradient(circle at 78% 12%, #fff 0 1.5px, transparent 2.5px), radial-gradient(circle at 42% 72%, #fff 0 1.5px, transparent 2.5px), radial-gradient(circle at 90% 64%, var(--brand) 0 2px, transparent 3px), radial-gradient(circle at 26% 88%, #fff 0 1px, transparent 2px), radial-gradient(circle at 60% 30%, #fff 0 1px, transparent 2px)",
  backgroundSize: "340px 340px",
};

export function XmasBanner({ home }: { home: HomeSettings }) {
  if (!home.xmasEnabled) return null;
  const photo = home.xmasPhotos[0];

  return (
    <section aria-label={home.xmasEyebrow} className="py-12 md:py-16">
      <Container>
        <Link
          href="/uznemumiem#ziemassvetki"
          data-reveal
          className="group relative isolate grid grid-cols-1 items-center gap-6 overflow-hidden rounded-[2rem] bg-ink p-6 text-white sm:grid-cols-[minmax(0,1fr)_auto] sm:p-8 md:grid-cols-[180px_minmax(0,1fr)_auto] md:gap-8 md:p-10"
        >
          <div aria-hidden className="absolute inset-0 -z-10 opacity-60" style={stars} />
          {photo && (
            <div className="relative hidden aspect-square w-[180px] -rotate-3 overflow-hidden rounded-2xl border-[6px] border-white transition-transform duration-500 group-hover:rotate-0 md:block">
              <Photo src={photo.src} alt={photo.caption} fill sizes="180px" className="object-cover" />
            </div>
          )}
          <div className="min-w-0">
            <p className="inline-flex rounded-full bg-brand px-3.5 py-1 text-xs font-extrabold tracking-[0.12em] text-ink uppercase">
              ✦ {home.xmasEyebrow}
            </p>
            <h2 className="display mt-4 text-2xl sm:text-3xl md:text-4xl">
              {home.xmasTitle} {home.xmasHighlight && <span className="sticker-light">{home.xmasHighlight}</span>}
            </h2>
            <p className="mt-3 max-w-2xl leading-7 text-white/80">{home.xmasShort}</p>
          </div>
          <span className="inline-flex h-14 items-center justify-center gap-2 rounded-full bg-brand px-7 font-extrabold whitespace-nowrap text-ink transition-transform group-hover:translate-x-1">
            Ziemassvētku piedāvājumi →
          </span>
        </Link>
      </Container>
    </section>
  );
}

export type XmasVariant = "tumsais" | "foto" | "saraksts";

type FeatureProps = {
  home: HomeSettings;
  /** Ziemassvētku piedāvājumi (pakalpojumi ar sezonu "Ziema") */
  services: Service[];
  /** Izkārtojums — sk. zemāk */
  variant?: XmasVariant;
};

const INQUIRY = "/kontakti?pakalpojums=izrades#pieprasijums";

/**
 * Ziemassvētku bloks lapā "Uzņēmumiem". Trīs izkārtojumi:
 *  - "tumsais"  — tumšs fons ar zvaigznēm: teksts + fotogrāfija, zem tiem piedāvājumu kartītes;
 *  - "foto"     — fotogrāfija pa visu platumu fonā, teksts centrā, kartītes zem tā;
 *  - "saraksts" — gaišs fons: kreisajā pusē teksts, labajā — piedāvājumi kā kompakts saraksts.
 */
export function XmasFeature({ home, services, variant = "tumsais" }: FeatureProps) {
  if (!home.xmasEnabled) return null;
  if (variant === "foto") return <XmasPhoto home={home} services={services} />;
  if (variant === "saraksts") return <XmasList home={home} services={services} />;
  return <XmasDark home={home} services={services} />;
}

function Cards({ services }: { services: Service[] }) {
  if (services.length === 0) return null;
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {services.map((s, i) => (
        <ServiceCard key={s.slug} service={s} href={businessHref(s.slug)} index={i} />
      ))}
    </div>
  );
}

function Points({ home }: { home: HomeSettings }) {
  if (home.xmasPoints.length === 0) return null;
  return (
    <ul className="mt-8 grid gap-3 sm:grid-cols-2">
      {home.xmasPoints.map((p) => (
        <li key={p} className="flex items-start gap-3 font-semibold">
          <span aria-hidden className="text-brand-strong">
            ✦
          </span>
          {p}
        </li>
      ))}
    </ul>
  );
}

/* ── A: tumšais ────────────────────────────────────────────────────── */
function XmasDark({ home, services }: FeatureProps) {
  return (
    <section id="ziemassvetki" aria-labelledby="ziemassvetki-virsraksts" className="relative isolate scroll-mt-20 overflow-hidden bg-ink py-16 text-white md:py-24">
      <div aria-hidden className="absolute inset-0 -z-10 opacity-60" style={stars} />
      <Container className="grid grid-cols-1 items-center gap-12 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]">
        <div data-reveal>
          <p className="inline-flex rounded-full bg-brand px-4 py-1.5 text-xs font-extrabold tracking-[0.12em] text-ink uppercase">{home.xmasEyebrow}</p>
          <h2 id="ziemassvetki-virsraksts" className="display mt-6 text-4xl sm:text-5xl lg:text-6xl">
            Ziemassvētku <span className="sticker-light">piedāvājumi</span>
          </h2>
          <p className="mt-6 max-w-xl text-lg leading-8 text-white/80">{home.xmasText}</p>
          <Points home={home} />
          <div className="mt-10 flex flex-wrap gap-3">
            <ButtonLink href={INQUIRY} size="lg" arrow>
              Pieprasīt piedāvājumu
            </ButtonLink>
            <ButtonLink href="/izrades" size="lg" variant="ghostLight">
              Ziemassvētku izrādes
            </ButtonLink>
          </div>
        </div>
        {home.xmasPhotos[0] && (
          <div data-reveal className="relative aspect-[4/3] overflow-hidden rounded-[1.75rem] bg-white/5 lg:aspect-[5/4]">
            <Photo src={home.xmasPhotos[0].src} alt={home.xmasPhotos[0].caption} fill sizes="(min-width: 1024px) 45vw, 100vw" className="object-cover" />
          </div>
        )}
      </Container>
      <Container className="mt-14 md:mt-16">
        <Cards services={services} />
      </Container>
    </section>
  );
}

/* ── B: fotogrāfija fonā ───────────────────────────────────────────── */
function XmasPhoto({ home, services }: FeatureProps) {
  const photo = home.xmasPhotos[0];
  return (
    <section id="ziemassvetki" aria-labelledby="ziemassvetki-virsraksts" className="scroll-mt-20">
      <div className="relative isolate overflow-hidden bg-ink pt-20 pb-40 text-center text-white md:pt-28 md:pb-52">
        {photo && <Photo src={photo.src} alt="" fill sizes="100vw" className="-z-20 object-cover" />}
        <div aria-hidden className="absolute inset-0 -z-10 bg-ink/70" />
        <Container>
          <div data-reveal className="mx-auto max-w-3xl">
            <p className="inline-flex rounded-full bg-brand px-4 py-1.5 text-xs font-extrabold tracking-[0.12em] text-ink uppercase">{home.xmasEyebrow}</p>
            <h2 id="ziemassvetki-virsraksts" className="display mt-6 text-4xl sm:text-5xl lg:text-6xl">
              Ziemassvētku <span className="sticker-light">piedāvājumi</span>
            </h2>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-white/85">{home.xmasText}</p>
            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <ButtonLink href={INQUIRY} size="lg" arrow>
                Pieprasīt piedāvājumu
              </ButtonLink>
              <ButtonLink href="/izrades" size="lg" variant="ghostLight">
                Ziemassvētku izrādes
              </ButtonLink>
            </div>
          </div>
        </Container>
      </div>
      {/* Kartītes pārklājas ar fotogrāfijas apakšu */}
      <Container className="relative -mt-28 pb-16 md:-mt-36 md:pb-24">
        <Cards services={services} />
      </Container>
    </section>
  );
}

/* ── C: gaišais ar sarakstu ────────────────────────────────────────── */
function XmasList({ home, services }: FeatureProps) {
  return (
    <section id="ziemassvetki" aria-labelledby="ziemassvetki-virsraksts" className="scroll-mt-20 bg-surface py-16 md:py-24">
      <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-16">
        <div data-reveal>
          <p className="inline-flex rounded-full bg-ink px-4 py-1.5 text-xs font-extrabold tracking-[0.12em] text-brand uppercase">{home.xmasEyebrow}</p>
          <h2 id="ziemassvetki-virsraksts" className="display mt-6 text-4xl sm:text-5xl">
            Ziemassvētku <span className="sticker">piedāvājumi</span>
          </h2>
          <p className="mt-6 max-w-xl text-lg leading-8 text-ink-soft">{home.xmasText}</p>
          <Points home={home} />
          <div className="mt-10 flex flex-wrap gap-3">
            <ButtonLink href={INQUIRY} size="lg" variant="dark" arrow>
              Pieprasīt piedāvājumu
            </ButtonLink>
          </div>
        </div>

        <ul data-reveal className="divide-y divide-line overflow-hidden rounded-[1.75rem] bg-white ring-1 ring-line">
          {services.map((s) => (
            <li key={s.slug}>
              <Link href={businessHref(s.slug)} className="group flex items-center gap-5 p-4 transition-colors hover:bg-brand/15 sm:p-5">
                <span className="relative size-20 shrink-0 overflow-hidden rounded-2xl bg-surface sm:size-24">
                  {s.heroImage && <Photo src={s.heroImage} alt="" fill sizes="96px" className="object-cover" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-base font-bold uppercase sm:text-lg">{s.title}</span>
                  <span className="mt-1 line-clamp-2 text-sm leading-6 text-ink-soft">{s.excerpt}</span>
                </span>
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-ink text-white transition-transform group-hover:translate-x-1" aria-hidden>
                  →
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}
