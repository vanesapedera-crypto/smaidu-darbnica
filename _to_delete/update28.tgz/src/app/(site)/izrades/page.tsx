import InquiryForm from "@/components/site/InquiryForm";
import VideoShowcase from "@/components/site/VideoShowcase";
import { StageHeading, StageHero } from "@/components/site/stage";
import { ButtonLink, Container, Section } from "@/components/site/ui";
import { getServices, getSettings } from "@/lib/content/queries";
import { pageMetadata } from "@/lib/seo";

export const revalidate = 3600;


export function generateMetadata() {
  return pageMetadata({
    path: "/izrades",
    title: "Izrādes bērniem un ģimenēm",
    description:
      "Interaktīvas Ziemassvētku un tematiskās izrādes uzņēmumu pasākumiem, pašvaldību svētkiem, skolām un bērnudārziem visā Latvijā. Noskatieties video.",
  });
}

export default async function ShowsPage() {
  const [{ shows, contact }, services] = await Promise.all([getSettings(), getServices("business")]);
  const tel = (p: string) => `tel:${p.replace(/\s/g, "")}`;

  return (
    <>
      <StageHero
        eyebrow="Izrādes · uzņēmumiem un pašvaldībām"
        title={shows.heroTitle}
        highlight={shows.heroHighlight}
        text={shows.heroText}
        crumbs={[{ name: "Izrādes", path: "/izrades" }]}
        photos={[
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-03.webp", caption: "Ziemassvētku izrāde" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-23.webp", caption: "Rūķi uz skatuves" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-10.webp", caption: "Ziemassvētku izrāde" },
        ]}
      >
        <ButtonLink href="#video" size="lg" arrow>
          Skatīties video
        </ButtonLink>
        <ButtonLink href="#pieprasijums" size="lg" variant="ghostLight">
          Pieprasīt izrādi
        </ButtonLink>
      </StageHero>

      {shows.videos.length > 0 && (
        <Section id="video" className="scroll-mt-20">
          <Container>
            <StageHeading eyebrow="Video" title={shows.videosTitle} highlight="izrādes" className="mb-12" />
            <VideoShowcase videos={shows.videos} />
          </Container>
        </Section>
      )}

      <Section id="pieprasijums" className="scroll-mt-20">
        <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
          <div>
            <StageHeading
              eyebrow="Pieprasījums"
              title="Izrāde jūsu"
              highlight="pasākumam"
              text="Uzrakstiet datumu, vietu un aptuveno skatītāju skaitu — atsūtīsim piedāvājumu."
            />
            <p data-reveal className="mt-8 font-semibold">
              Vai zvaniet:{" "}
              <a href={tel(contact.phoneBusiness)} className="underline decoration-brand decoration-2 underline-offset-4">
                {contact.phoneBusiness}
              </a>
            </p>
          </div>
          <div data-reveal>
            <InquiryForm
              services={services.map(({ slug, title }) => ({ slug, title }))}
              defaultService={services.some((s) => s.slug === "ziemassvetku-pasakumi") ? "ziemassvetku-pasakumi" : ""}
            />
          </div>
        </Container>
      </Section>
    </>
  );
}
