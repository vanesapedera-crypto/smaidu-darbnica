import type { PriceGroup } from "@/lib/content/types";

/**
 * Aptuvenās cenas aprēķins privātajām ballītēm.
 *
 * Iepriekš cenas bija ierakstītas kodā atsevišķi no programmu datiem un vairākās
 * vietās nesakrita. Tagad tās tiek nolasītas no programmas cenrāža (ko var labot
 * administrēšanas panelī), atpazīstot tipiskos formulējumus:
 *   "Līdz 15 bērniem" · "Mazā grupa (1–6 bērni)" · "No 10 līdz 15 bērniem" · "Katrs nākamais bērns"
 */

/** Telpu noma Smaidu Darbnīcā (3 h) */
export const VENUE_PRICE = { weekday: 90, weekend: 110 } as const;
export const VENUE_TIMES = ["10:00", "14:00", "18:00"] as const;

/** Telpu nomas laika posmi (3 stundas) rādīšanai lapā un formā; vērtība saglabājas kā sākuma laiks */
export const VENUE_SLOTS = VENUE_TIMES.map((t) => {
  const end = `${String(Number(t.slice(0, 2)) + 3).padStart(2, "0")}${t.slice(2)}`;
  return { value: t, label: `${t}–${end}` };
});

export function venuePrice(date: string): number | null {
  if (!date) return null;
  const day = new Date(`${date}T12:00:00`).getDay();
  return day === 0 || day === 5 || day === 6 ? VENUE_PRICE.weekend : VENUE_PRICE.weekday;
}

type Tier = { max: number; price: number };

function parseGroup(group: PriceGroup) {
  const tiers: Tier[] = [];
  let extra: number | null = null;
  let flat: number | null = null;

  for (const { label, price } of group.options) {
    if (price === null) continue;
    const l = label.toLowerCase();
    if (l.includes("nākam")) {
      extra = price;
      continue;
    }
    if (l.includes("€/km") || l.includes("ceļa")) continue;
    // Lielākais skaitlis etiķetē ir grupas augšējā robeža
    const numbers = (label.match(/\d+/g) ?? []).map(Number).filter((n) => n < 1000);
    if (numbers.length && /bērn/.test(l)) tiers.push({ max: Math.max(...numbers), price });
    else if (flat === null) flat = price;
  }
  tiers.sort((a, b) => a.max - b.max);
  return { tiers, extra, flat };
}

/** Izvēlas cenrāža grupu pēc norises vietas (ja programmai ir atsevišķs izbraukuma cenrādis). */
function pickGroup(pricing: PriceGroup[], travelling: boolean): PriceGroup | undefined {
  if (pricing.length <= 1) return pricing[0];
  const travelGroup = pricing.find((g) => /izbrauk/i.test(g.title));
  if (travelGroup) return travelling ? travelGroup : pricing.find((g) => g !== travelGroup);
  return pricing[0];
}

/**
 * Zemākā programmas cena ("no X €") kartītēm un izvēlnēm.
 * Neņem vērā piemaksas par katru nākamo bērnu un ceļa izdevumus.
 */
export function fromPrice(pricing: PriceGroup[]): number | null {
  const prices = pricing
    .flatMap((g) => g.options)
    .filter((o) => o.price !== null && !/nākam|€\/km|ceļa/i.test(o.label))
    .map((o) => o.price as number);
  return prices.length ? Math.min(...prices) : null;
}

/** Atgriež aptuveno programmas cenu vai null, ja to nevar aprēķināt (pēc vienošanās). */
export function estimateProgramPrice(pricing: PriceGroup[], children: number, travelling: boolean): number | null {
  const group = pickGroup(pricing, travelling);
  if (!group) return null;
  const { tiers, extra, flat } = parseGroup(group);

  if (tiers.length === 0) return flat;
  if (!children) return null;

  const tier = tiers.find((t) => children <= t.max);
  if (tier) return tier.price;

  const largest = tiers[tiers.length - 1];
  return extra === null ? null : largest.price + (children - largest.max) * extra;
}
