import { Baby, Check, Coffee, Disc3, Gamepad2, Mountain, ScrollText, Sparkles } from "lucide-react";
import PhotoReel from "@/components/site/PhotoReel";
import RichText from "@/components/site/RichText";
import { CtaBand } from "@/components/site/sections";
import { StageHeading, StageHero } from "@/components/site/stage";
import { ButtonLink, Container, Section } from "@/components/site/ui";
import { toReel } from "@/lib/content/media";
import { getCategoryImages, getSettings } from "@/lib/content/queries";
import { VENUE_PRICE, VENUE_TIMES } from "@/lib/pricing";
import { pageMetadata } from "@/lib/seo";

export const revalidate = 3600;

export function generateMetadata() {
  return pageMetadata({
    path: "/telpu-noma",
    title: "Telpu noma svētkiem Tukumā",
    description: `Telpu noma bērnu dzimšanas dienām un ģimenes svētkiem Tukumā: bumbu baseins, rotaļu istaba, disko zāle un virtuve. No ${VENUE_PRICE.weekday} € par 3 stundām.`,
  });
}

// Ikonas aprīkojuma kartītēm (pēc kārtas; saturs — panelī "Telpu noma")
const ICONS = [Sparkles, Gamepad2, Baby, Disc3, Mountain, Coffee];

const PRICES = [
  { title: "Pirmdiena–ceturtdiena", note: "3 stundas", price: `${VENUE_PRICE.weekday} €` },
  { title: "Piektdiena–svētdiena", note: "3 stundas", price: `${VENUE_PRICE.weekend} €` },
  { title: "Papildu stunda", note: "Iepriekš vienojoties", price: "20 €" },
];

export default async function VenuePage() {
  const [photos, { contact, venue }] = await Promise.all([getCategoryImages(["telpas"], 24), getSettings()]);

  return (
    <>
      <StageHero
        eyebrow="Telpu noma · Tukums"
        title={venue.heroTitle}
        highlight={venue.heroHighlight}
        after={venue.heroAfter}
        text={venue.heroText}
        crumbs={[{ name: "Telpu noma", path: "/telpu-noma" }]}
        photos={[
          { src: "/media/telpas/telpas-26.webp", caption: "Bumbu baseins" },
          { src: "/media/telpas/telpas-24.webp", caption: "Disko zāle" },
          { src: "/media/telpas/telpas-07.webp", caption: "Svētku galds" },
        ]}
      >
        <ButtonLink href="/izklaides-programmas/pieteikt" size="lg" variant="dark" arrow>
          Rezervēt telpas
        </ButtonLink>
        <ButtonLink href="#noteikumi" size="lg" variant="outlineDark">
          Lietošanas noteikumi
        </ButtonLink>
      </StageHero>

      {/* Par telpām + aprīkojums */}
      <Section>
        <Container>
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            <StageHeading eyebrow="Par telpām" title={venue.aboutTitle} />
            <div data-reveal>
              <RichText text={venue.about} className="prose-sd text-lg" />
            </div>
          </div>
          {venue.features.length > 0 && (
            <ul className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {venue.features.map(({ title, description }, i) => {
                const Icon = ICONS[i % ICONS.length];
                return (
                  <li key={title} data-reveal className="rounded-[1.5rem] bg-surface p-7">
                    <span className="grid size-12 place-items-center rounded-full bg-brand">
                      <Icon className="size-5" aria-hidden />
                    </span>
                    <h3 className="mt-5 text-lg font-extrabold">{title}</h3>
                    <p className="mt-2 leading-7 text-ink-soft">{description}</p>
                  </li>
                );
              })}
            </ul>
          )}
        </Container>
      </Section>

      <Section tone="surface">
        <Container>
          <StageHeading eyebrow="Cenas" title="Cenrādis" text={`Sākuma laiki: ${VENUE_TIMES.join(", ")}.`} />
          <dl className="mt-12 grid gap-5 md:grid-cols-3">
            {PRICES.map((p, i) => (
              <div key={p.title} data-reveal className={`rounded-[1.75rem] p-8 ${i === 1 ? "bg-ink text-white md:-rotate-1" : "bg-white ring-1 ring-line md:rotate-1"}`}>
                <dt>
                  <span className="block font-display text-lg font-bold uppercase">{p.title}</span>
                  <span className={i === 1 ? "text-white/65" : "text-ink/70"}>{p.note}</span>
                </dt>
                <dd className={`mt-8 font-display text-6xl font-extrabold ${i === 1 ? "text-brand" : ""}`}>{p.price}</dd>
              </div>
            ))}
          </dl>

          {venue.included.length > 0 && (
            <div data-reveal className="mt-8 rounded-[1.75rem] bg-white p-8 ring-1 ring-line">
              <h3 className="font-display text-lg font-bold uppercase">Cenā iekļauts</h3>
              <ul className="mt-6 grid gap-x-10 gap-y-3 md:grid-cols-2">
                {venue.included.map((item) => (
                  <li key={item} className="flex items-start gap-3 leading-7">
                    <span className="mt-1 grid size-5 shrink-0 place-items-center rounded-full bg-brand">
                      <Check className="size-3" aria-hidden />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Container>
      </Section>

      {/* Telpu lietošanas noteikumi — teksts rediģējams panelī */}
      {venue.rules.trim() && (
        <Section id="noteikumi" className="scroll-mt-20">
          <Container className="grid grid-cols-1 gap-10 lg:grid-cols-[minmax(0,0.75fr)_minmax(0,1.25fr)]">
            <div className="lg:sticky lg:top-28 lg:self-start">
              <span className="grid size-14 place-items-center rounded-full bg-brand">
                <ScrollText className="size-6" aria-hidden />
              </span>
              <StageHeading className="mt-6" eyebrow="Noteikumi" title="Telpu lietošanas" highlight="noteikumi" text="Lūdzam iepazīties pirms rezervācijas — tā svētki noritēs bez raizēm." />
            </div>
            <div data-reveal className="rounded-[2rem] bg-white p-7 ring-1 ring-line sm:p-10">
              <RichText text={venue.rules} />
            </div>
          </Container>
        </Section>
      )}

      {photos.length > 0 && (
        <section className="overflow-hidden bg-brand-soft pt-20 pb-12 md:pt-28">
          <Container>
            <StageHeading eyebrow="Foto" title="Ieskaties" highlight="telpās" />
          </Container>
          <PhotoReel images={toReel(photos)} />
        </section>
      )}

      <CtaBand
        title="Rezervējiet telpas"
        text="Izvēlieties datumu un laiku — telpas varat nomāt atsevišķi vai kopā ar kādu no mūsu izklaides programmām."
        contact={{ ...contact, phoneBusiness: contact.phonePrivate, phoneBusinessPerson: contact.phonePrivatePerson }}
        href="/izklaides-programmas/pieteikt"
        label="Rezervēt telpas"
      />
    </>
  );
}
