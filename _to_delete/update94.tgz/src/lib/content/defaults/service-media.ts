/**
 * Papildu materiāli uzņēmumu pakalpojumu lapām (pēc pakalpojuma slug):
 *  - SERVICE_PHOTOS — bilžu režģis zem apraksta (faili mapē public/media/<slug>/);
 *  - SERVICE_HERO_VIDEO — YouTube video ID fonam lapas galvenē.
 */
const range = (slug: string, count: number) =>
  Array.from({ length: count }, (_, i) => `/media/${slug}/${slug}-${String(i + 1).padStart(2, "0")}.webp`);

export const SERVICE_PHOTOS: Record<string, string[]> = {
  "pasakumu-organizesana": range("pasakumu-organizesana", 15),
};

export const SERVICE_HERO_VIDEO: Record<string, string> = {
  "pasakumu-organizesana": "HFTc7zIuO0E",
};
