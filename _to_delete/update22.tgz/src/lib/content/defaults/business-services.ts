import type { Service } from "../types";

/**
 * Pakalpojumi uzņēmumiem un pašvaldībām (noklusējuma saturs / seed).
 * Tekstus var labot administrēšanas panelī sadaļā "Pakalpojumi".
 */

type Draft = Omit<
  Service,
  "audience" | "pricing" | "published" | "age" | "seoTitle" | "seoDescription"
> & Partial<Pick<Service, "pricing" | "age">>;

const INDIVIDUAL =
  "Cena atkarīga no dalībnieku skaita, ilguma un norises vietas. Sagatavosim individuālu piedāvājumu vienas darba dienas laikā.";

const drafts: Draft[] = [
  {
    slug: "komandas-saliedesana",
    title: "Komandas saliedēšana",
    icon: "Users",
    excerpt:
      "Aktīvas un radošas komandas spēles, kas stiprina sadarbību, uzlabo komunikāciju un vienkārši sagādā prieku kolēģiem.",
    intro:
      "Labākā komanda veidojas tad, kad cilvēki kopā smejas, sadarbojas un uzvar. Mēs izveidosim komandas saliedēšanas programmu, kas atbilst jūsu uzņēmuma mērķim un kolektīva noskaņojumam.",
    body:
      "Programmu veidojam no pārbaudītām komandas spēlēm, loģikas uzdevumiem un lielformāta atrakcijām. Katru aktivitāti vada pieredzējis vadītājs, kurš seko, lai iesaistīti ir visi — arī tie, kuri parasti stāv malā.\n\nPasākums var notikt jūsu birojā, brīvā dabā vai jebkurā citā vietā Latvijā. Pēc vēlēšanās apvienojam to ar vakara programmu, bērnu zonu vai ģimenes dienu.",
    highlights: [
      "Programma pielāgota komandas lielumam un mērķim",
      "Pieredzējuši spēļu vadītāji",
      "Lielformāta un loģikas spēles",
      "Iekštelpās vai brīvā dabā",
      "Apbalvošana un foto mirkļi",
    ],
    suitableFor: ["Uzņēmumu kolektīvi", "Jaunu darbinieku iepazīšanās", "Nodaļu sadarbības dienas", "Skolotāju kolektīvi"],
    activities: [
      { title: "Iesildīšanās", description: "Viegls sākums, kas palīdz dalībniekiem atbrīvoties un iepazīties." },
      { title: "Komandu izaicinājumi", description: "Stafetes, loģikas uzdevumi un spēles, kurās uzvar sadarbība." },
      { title: "Lielā misija", description: "Noslēguma uzdevums, kurā visām komandām jāapvieno spēki." },
      { title: "Apbalvošana", description: "Rezultātu paziņošana, balvas un kopīga fotogrāfija." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik ilga ir programma?", answer: "Parasti 1,5–3 stundas, bet ilgumu pielāgojam jūsu dienas plānam." },
      { question: "Vai varat atbraukt pie mums?", answer: "Jā, strādājam visā Latvijā — birojos, viesu namos, parkos un pasākumu vietās." },
      { question: "Kas notiek, ja līst lietus?", answer: "Sagatavojam rezerves plānu ar aktivitātēm iekštelpās vai zem nojumes." },
    ],
    duration: "1,5–3 stundas",
    participants: "10–200 dalībnieku",
    heroImage: "/media/stiga-meza-dienas/stiga-meza-dienas-05.webp",
    albums: ["stiga-meza-dienas", "lielformata-speles", "vizium-jubileja"],
    seasons: ["visu-gadu"],
    sort: 10,
  },
  {
    slug: "sporta-speles",
    title: "Sporta spēles",
    icon: "Trophy",
    excerpt:
      "Sporta dienas un aktīvas stafetes uzņēmumiem, skolām un pašvaldībām — ar tiesnešiem, inventāru un apbalvošanu.",
    intro:
      "Kustība, azarts un veselīga sacensība. Organizējam sporta spēles, kurās var piedalīties ikviens neatkarīgi no fiziskās sagatavotības.",
    body:
      "Sagatavojam disciplīnu programmu, nodrošinām inventāru, vadītājus un rezultātu uzskaiti. Disciplīnas izvēlamies tā, lai tās būtu jautras un drošas, nevis tikai spēka pārbaude.\n\nSporta spēles lieliski der uzņēmuma vasaras sporta dienai, skolas pasākumam vai pagasta svētkiem, un tās var papildināt ar bērnu zonu ģimenēm.",
    highlights: [
      "Disciplīnas visām vecuma grupām",
      "Inventārs un tiesneši",
      "Rezultātu uzskaite un apbalvošana",
      "Iespēja pievienot bērnu zonu",
    ],
    suitableFor: ["Uzņēmumu sporta dienas", "Skolas un bērnudārzi", "Pagastu un novadu svētki", "Ģimenes dienas"],
    activities: [
      { title: "Komandu stafetes", description: "Klasiskas un netradicionālas stafetes ar jautriem uzdevumiem." },
      { title: "Veiklības disciplīnas", description: "Koka kājas, mešana mērķī, līdzsvara un precizitātes uzdevumi." },
      { title: "Lielformāta spēles", description: "Milzu spēles, kas piesaista gan bērnus, gan pieaugušos." },
      { title: "Apbalvošana", description: "Medaļas, diplomi un uzvarētāju foto." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai jānodrošina inventārs?", answer: "Nē, visu nepieciešamo inventāru atvedam paši." },
      { question: "Cik dalībnieku var piedalīties?", answer: "No nelielām komandām līdz vairākiem simtiem dalībnieku vienlaikus." },
    ],
    duration: "2–4 stundas",
    participants: "20–500 dalībnieku",
    heroImage: "/media/stiga-meza-dienas/stiga-meza-dienas-02.webp",
    albums: ["stiga-meza-dienas", "lielformata-speles", "vimbu-svetki-2026"],
    seasons: ["vasara", "visu-gadu"],
    sort: 20,
  },
  {
    slug: "uznemumu-pasakumi",
    title: "Uzņēmumu pasākumi",
    icon: "Building2",
    excerpt:
      "Jubilejas, atvēršanas svētki, klientu dienas un festivāli — pilna pasākuma organizēšana no scenārija līdz noslēgumam.",
    intro:
      "Uzņēmuma jubileja, jauna biroja atklāšana, klientu diena vai zīmola festivāls — mēs izveidosim pasākumu, kas atspoguļo jūsu uzņēmuma vērtības un paliek atmiņā viesiem.",
    body:
      "Uzņemamies visu organizatorisko darbu: scenāriju, vadītāju, izklaides programmu, dekorācijas, atrakcijas un bērnu zonu. Jums ir viens kontakts, kas koordinē visu dienu.\n\nMēs esam strādājuši gan ar nelieliem kolektīviem, gan ar publiskiem pasākumiem, kuros piedalās tūkstošiem apmeklētāju.\n\n## Ko varam nodrošināt\n- Pasākuma koncepciju un scenāriju\n- Vadītāju un animatorus\n- Šovus: burbuļu, zinātnes, tematiskos tēlus\n- Lielformāta spēles un atrakcijas\n- Bērnu zonu ar pieskatīšanu\n- Foto stūrus un dekorācijas",
    highlights: [
      "Pilna pasākuma organizēšana",
      "Personīgs projekta vadītājs",
      "Programma bērniem un pieaugušajiem",
      "Zīmola krāsas un tematika dekorācijās",
      "Rēķins uzņēmumam un līgums",
    ],
    suitableFor: ["Uzņēmumu jubilejas", "Klientu un partneru dienas", "Zīmola festivāli", "Atvēršanas svētki"],
    activities: [
      { title: "Koncepcija", description: "Kopā definējam mērķi, auditoriju un pasākuma noskaņu." },
      { title: "Programma", description: "Izveidojam dienas plānu ar šoviem, aktivitātēm un pauzēm." },
      { title: "Norise", description: "Mūsu komanda vada pasākumu, jūs baudāt svētkus kopā ar viesiem." },
      { title: "Noslēgums", description: "Sakārtojam vietu un pēc vēlēšanās nododam foto materiālus." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik laicīgi jāpiesaka pasākums?", answer: "Ieteicams 3–6 nedēļas iepriekš, sezonas laikā (jūnijs, decembris) — agrāk." },
      { question: "Vai varat strādāt ar mūsu zīmolu?", answer: "Jā, dekorācijas, foto stūri un aktivitātes var veidot jūsu zīmola krāsās un tematikā." },
      { question: "Vai izrakstāt rēķinu uzņēmumam?", answer: "Jā, strādājam ar līgumu un rēķinu juridiskai personai." },
    ],
    duration: "Pēc vienošanās",
    participants: "50–5000 apmeklētāju",
    heroImage: "/media/vizium-jubileja/vizium-jubileja-07.webp",
    albums: ["vizium-jubileja", "elyndi-fest-2026", "bauska-taste-2024", "bauska-taste-2022"],
    seasons: ["visu-gadu"],
    sort: 30,
  },
  {
    slug: "vasaras-pasakumi",
    title: "Vasaras pasākumi",
    icon: "Sun",
    excerpt:
      "Pilsētu svētki, ģimenes dienas un vasaras festivāli ar aktivitātēm, šoviem un bērnu zonām brīvā dabā.",
    intro:
      "Vasara ir svētku laiks. Veidojam aktīvas un krāsainas programmas pilsētu un novadu svētkiem, uzņēmumu ģimenes dienām un festivāliem brīvā dabā.",
    body:
      "Mūsu vasaras programmas apvieno tematiskus tēlus, radošās darbnīcas, lielformāta spēles, burbuļu šovus un sejas apgleznošanu. Viss tiek plānots tā, lai apmeklētāju plūsma būtu vienmērīga un ikvienam atrastos kāda nodarbe.\n\nKatru gadu strādājam tādos pasākumos kā Tukuma Rožu svētki un Dobeles pilsētas svētki, tāpēc zinām, kā organizēt aktivitātes lielam cilvēku skaitam.",
    highlights: [
      "Tematiskas zonas un tēli",
      "Aktivitātes visām vecuma grupām",
      "Pieredze lielos publiskos pasākumos",
      "Nojumes, inventārs un dekorācijas",
    ],
    suitableFor: ["Pilsētu un novadu svētki", "Ģimenes dienas", "Festivāli", "Vasaras sporta dienas"],
    activities: [
      { title: "Tematiskās zonas", description: "Tējnīcas, pasaku pasaules, radošie stūri un foto vietas." },
      { title: "Šovi un tēli", description: "Burbuļu šovi, tematiskie tēli un muzikāli priekšnesumi." },
      { title: "Spēles un atrakcijas", description: "Lielformāta spēles, stafetes un veiklības uzdevumi." },
      { title: "Radošās darbnīcas", description: "Darbnīcas, kurās bērni paši izgatavo suvenīru." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai nodrošināt nojumes?", answer: "Pēc vajadzības nodrošinām nojumes un aprīkojumu savām aktivitāšu zonām." },
      { question: "Cik ilgi varat strādāt?", answer: "Varam strādāt visu svētku dienu, sadalot programmu vairākos blokos." },
    ],
    duration: "3–10 stundas",
    participants: "100–5000 apmeklētāju",
    heroImage: "/media/tukuma-rozu-svetki-2025/tukuma-rozu-svetki-2025-09.webp",
    albums: ["tukuma-rozu-svetki-2025", "dobeles-pilsetas-svetki-2026", "tukuma-rozu-svetki-2024", "dobeles-abolu-svetki-2024"],
    seasons: ["vasara"],
    sort: 40,
  },
  {
    slug: "ziemassvetku-pasakumi",
    title: "Ziemassvētku pasākumi",
    icon: "TreePine",
    excerpt:
      "Ziemassvētku izrādes, rūķu programmas un Ziemassvētku vecīša apciemojumi darbinieku bērniem un pilsētu svētkiem.",
    intro:
      "Gada siltākie svētki. Veidojam Ziemassvētku pasākumus uzņēmumu darbinieku ģimenēm, pašvaldībām un skolām — ar izrādi, rūķiem, dāvanām un īstu svētku sajūtu.",
    body:
      "Mūsu Ziemassvētku programmā ir interaktīva izrāde ar rūķiem, Ziemassvētku vecītis ar dāvanu pasniegšanu, radošās darbnīcas un svētku diskotēka. Programmu veidojam gan skatuvei, gan nelielām telpām.\n\nDecembris ir mūsu noslogotākais mēnesis, tāpēc aicinām pieteikties laikus — vēlams jau oktobrī vai novembra sākumā.",
    highlights: [
      "Interaktīva izrāde ar rūķiem",
      "Ziemassvētku vecītis un dāvanu pasniegšana",
      "Radošās darbnīcas un piparkūku dekorēšana",
      "Programma skatuvei vai telpai",
      "Dāvanu paku organizēšana pēc vienošanās",
    ],
    suitableFor: ["Darbinieku bērnu svētki", "Pašvaldību egles iedegšana", "Skolas un bērnudārzi", "Klientu pasākumi"],
    activities: [
      { title: "Sagaidīšana", description: "Rūķi sagaida viesus un ievada svētku noskaņā." },
      { title: "Izrāde", description: "Interaktīva Ziemassvētku izrāde, kurā piedalās arī bērni." },
      { title: "Ziemassvētku vecītis", description: "Dzejolīši, dāvanas un kopīgas fotogrāfijas." },
      { title: "Darbnīcas un diskotēka", description: "Radošās darbnīcas un svētku ballīte noslēgumā." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Kad jāpiesaka Ziemassvētku pasākums?", answer: "Ieteicams līdz novembra sākumam — decembra nedēļas nogales aizpildās visātrāk." },
      { question: "Vai varat nodrošināt dāvanas?", answer: "Jā, pēc vienošanās palīdzam sagatavot un pasniegt dāvanu pakas." },
    ],
    duration: "1–2 stundas",
    participants: "20–1000 dalībnieku",
    heroImage: "/media/ziemassvetki-2025/ziemassvetki-2025-03.webp",
    albums: ["ziemassvetki-2025"],
    seasons: ["ziema"],
    sort: 50,
  },
  {
    slug: "radosas-darbnicas",
    title: "Radošās darbnīcas",
    icon: "Palette",
    excerpt:
      "Radošās darbnīcas bērniem un pieaugušajiem — dalībnieki paši izgatavo suvenīru, ko paņemt līdzi.",
    intro:
      "Radošās darbnīcas ir lielisks veids, kā pasākumā iesaistīt apmeklētājus un dāvāt viņiem paliekošu atmiņu. Tematiku pielāgojam sezonai, pasākumam vai jūsu zīmolam.",
    body:
      "Mēs atvedam visus materiālus, instrumentus un darbnīcu vadītājus. Darbnīcas var notikt nepārtraukti visu pasākuma laiku — apmeklētāji pienāk, izgatavo savu darbu un dodas tālāk.\n\nPopulārākās tēmas: sezonālie rotājumi, burvju nūjiņas, rokassprādzes, dabas materiālu darbi, slaims un svētku kartītes.",
    highlights: [
      "Visi materiāli iekļauti",
      "Tematika pēc pasākuma vai zīmola",
      "Piemērots plūsmas pasākumiem",
      "Suvenīrs katram dalībniekam",
    ],
    suitableFor: ["Pilsētu svētki un festivāli", "Uzņēmumu ģimenes dienas", "Klientu dienas", "Skolas pasākumi"],
    activities: [
      { title: "Sezonālie rotājumi", description: "Ziemassvētku, Lieldienu vai vasaras tēmas darbi." },
      { title: "Dabas materiāli", description: "Darbi no koka, sūnām, ziediem un citiem dabas materiāliem." },
      { title: "Rotaslietas", description: "Rokassprādzes, kaklarotas un matu rotas." },
      { title: "Slaims un eksperimenti", description: "Krāsainais slaims un vienkārši zinātnes eksperimenti." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik cilvēku var piedalīties vienlaikus?", answer: "Parasti 10–20 pie viena galda, bet varam iekārtot vairākas darbnīcu vietas." },
    ],
    duration: "2–8 stundas",
    participants: "Plūsmā līdz 1000 dalībnieku",
    heroImage: "/media/valpurgu-nakts-tervete-2026/valpurgu-nakts-tervete-2026-13.webp",
    albums: ["valpurgu-nakts-tervete-2026", "ziemassvetki-2025", "stiga-meza-dienas"],
    seasons: ["ziema", "vasara"],
    sort: 60,
  },
  {
    slug: "lielformata-speles",
    title: "Lielformāta spēles",
    icon: "Dices",
    excerpt:
      "Lielformāta spēļu programma ar 20 spēlēm — pielāgojam pasākuma vietai, dalībniekiem un mērķim. Uzstādām, vadām un apbalvojam.",
    intro:
      "Lielformāta spēļu programmu pielāgojam katra pasākuma vajadzībām, auditorijai un mērķim. Mēs nodrošinām visu norisi — no spēļu uzstādīšanas un vadīšanas līdz punktu skaitīšanai un uzvarētāju paziņošanai.",
    body:
      "No 20 pieejamajām spēlēm veidojam pasākumam piemērotāko kombināciju atbilstoši vietai, dalībnieku skaitam un pasākuma mērķim — komandu sacensībām, ģimenes dienai vai brīvai spēlēšanai festivālā.\n\n## Pieejamās spēles\n- Garās kājas\n- Jenga\n- Katapulta\n- Līdzsvara dēlis\n- Limbo\n- Melnais caurums\n- Slēpes\n- Smaidiņu cope\n- Veiksmīgais loms\n- Pīļuks pa dambi\n- Desas\n- Tornis\n- Saldumu zeme\n- Peļu slazds\n- Slinkais šoferītis\n- Lielformāta smaidiņš\n- Dambrete\n- Acenes\n- Bišu šūniņas\n- Bungas",
    highlights: [
      "20 dažādas lielformāta spēles",
      "Spēļu kombinācija pēc vietas, dalībniekiem un mērķa",
      "Uzstādīšana, vadīšana un punktu skaitīšana",
      "Uzvarētāju paziņošana",
      "Iekštelpās un brīvā dabā",
    ],
    suitableFor: ["Uzņēmumu pasākumi", "Komandu sacensības", "Pilsētu svētki un festivāli", "Ģimenes un sporta dienas"],
    activities: [
      { title: "Spēļu izvēle", description: "Kopā ar jums no 20 spēlēm izvēlamies pasākumam piemērotāko kombināciju." },
      { title: "Uzstādīšana", description: "Atvedam un uzstādām spēles pasākuma vietā — telpās vai brīvā dabā." },
      { title: "Spēles un sacensības", description: "Mūsu vadītāji skaidro noteikumus, vada spēles un skaita punktus." },
      { title: "Uzvarētāju paziņošana", description: "Noslēgumā apkopojam rezultātus un paziņojam uzvarētājus." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai spēles der komandu sacensībām?", answer: "Jā — mūsu vadītāji vada spēles, skaita punktus un noslēgumā paziņo uzvarētājus." },
      { question: "Vai varam izvēlēties konkrētas spēles?", answer: "Jā. No 20 spēlēm kopā izveidojam kombināciju, kas der jūsu vietai, dalībnieku skaitam un pasākuma mērķim." },
    ],
    duration: "2–8 stundas",
    participants: "Plūsmā līdz 2000 apmeklētāju",
    heroImage: "/media/lielformata-speles/lielformata-speles-01.webp",
    albums: ["lielformata-speles", "vimbu-svetki-2026", "bauska-taste-2024"],
    seasons: ["vasara"],
    sort: 70,
  },
  {
    slug: "burbulu-sovi",
    title: "Burbuļu šovi",
    icon: "Sparkles",
    excerpt:
      "Milzu ziepju burbuļu šovi un putu ballītes, kas pārvērš jebkuru pasākumu krāsainā piedzīvojumā.",
    intro:
      "Milzu burbuļi, kas lido pāri skatītāju galvām, un putu kalni, kuros var izskrieties — burbuļu šovs ir viena no pasākumu iecienītākajām sadaļām.",
    body:
      "Burbuļu šovu vada pieredzējis šovmenis, kas iesaista skatītājus un veido burbuļus visdažādākajos izmēros. Brīvā dabā piedāvājam arī milzu burbuļu zonu, kurā burbuļus var veidot paši apmeklētāji.\n\nPutu ballīte ar putu ģeneratoru ir lielisks noslēgums vasaras svētkiem un ģimenes dienām.",
    highlights: [
      "Interaktīvs šovs ar vadītāju",
      "Milzu burbuļu zona brīvā dabā",
      "Putu ballīte ar ģeneratoru",
      "Droši, ādai draudzīgi līdzekļi",
    ],
    suitableFor: ["Festivāli", "Pilsētu svētki", "Uzņēmumu ģimenes dienas", "Skolas pasākumi"],
    activities: [
      { title: "Burbuļu šovs", description: "30 minūšu priekšnesums ar skatītāju iesaisti." },
      { title: "Milzu burbuļu zona", description: "Apmeklētāji paši veido milzu burbuļus." },
      { title: "Putu ballīte", description: "Putu kalns ar mūziku un kustību spēlēm." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai burbuļu šovs notiek arī telpās?", answer: "Jā, šovu var rīkot telpās. Putu ballīte un milzu burbuļi paredzēti brīvā dabā." },
    ],
    duration: "30 min – 3 stundas",
    participants: "Līdz 1000 skatītāju",
    heroImage: "/media/vizium-jubileja/vizium-jubileja-09.webp",
    albums: ["vizium-jubileja", "putu-ballite", "stiga-meza-dienas"],
    seasons: ["vasara"],
    sort: 80,
  },
  {
    slug: "seju-apgleznosana",
    title: "Seju apgleznošana",
    icon: "Brush",
    excerpt:
      "Profesionāla seju apgleznošana un glitteru tetovējumi pasākumiem — ātri, krāsaini un ar drošām kosmētiskajām krāsām.",
    intro:
      "Seju apgleznošana ir viena no pieprasītākajām aktivitātēm jebkurā pasākumā. Mūsu mākslinieki strādā ātri, tāpēc rindas ir īsas, bet zīmējumi — krāsaini un precīzi.",
    body:
      "Izmantojam sertificētas kosmētiskās krāsas un glitterus, kas ir droši bērnu ādai. Dizainus pielāgojam pasākuma tēmai — no tauriņiem un supervaroņiem līdz jūsu zīmola krāsām un festivāla stilam.\n\nLieliem pasākumiem nodrošinām vairākus māksliniekus vienlaikus.",
    highlights: [
      "Droša, sertificēta kosmētika",
      "Dizaini bērniem un pieaugušajiem",
      "Glitteru tetovējumi un matu šķipsnas",
      "Vairāki mākslinieki lieliem pasākumiem",
    ],
    suitableFor: ["Festivāli", "Uzņēmumu ģimenes dienas", "Pilsētu svētki", "Sporta pasākumi"],
    activities: [
      { title: "Seju apgleznošana", description: "Klasiski un tematiski dizaini." },
      { title: "Glitteru tetovējumi", description: "Pagaidu tetovējumi ar kosmētisko glitteru." },
      { title: "Festivālu dizaini", description: "Glitteri un akcenti pieaugušajiem." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Cik cilvēkus var apgleznot stundā?", answer: "Viens mākslinieks stundā apglezno aptuveni 12–20 sejas atkarībā no dizaina." },
    ],
    duration: "1–8 stundas",
    participants: "12–20 sejas stundā uz mākslinieku",
    heroImage: "/media/tukuma-rozu-svetki-2025/tukuma-rozu-svetki-2025-07.webp",
    albums: ["sejas-apgleznosana", "tukuma-rozu-svetki-2025", "dobeles-pilsetas-svetki-2026"],
    seasons: ["vasara", "visu-gadu"],
    sort: 90,
  },
  {
    slug: "bernu-zona",
    title: "Bērnu zona uzņēmumu pasākumos",
    icon: "Baby",
    excerpt:
      "Droša un aprīkota bērnu zona ar animatoriem, lai vecāki var mierīgi baudīt pasākumu.",
    intro:
      "Kad pasākumā ir bērni, vecāki vēlas zināt, ka viņu atvases ir drošās rokās. Mēs iekārtojam bērnu zonu ar aktivitātēm, rotaļām un pieredzējušiem animatoriem.",
    body:
      "Bērnu zonu veidojam atbilstoši bērnu vecumam: mazuļiem — mīkstie moduļi un rotaļu stūrītis, lielākiem bērniem — spēles, radošās darbnīcas, sejas apgleznošana un tematiskie tēli.\n\nAnimatoru skaitu plānojam pēc bērnu skaita, lai katrs bērns būtu pieskatīts.",
    highlights: [
      "Pieredzējuši animatori",
      "Mazuļu stūrītis ar mīkstajiem moduļiem",
      "Aktivitātes dažādiem vecumiem",
      "Darbojas visu pasākuma laiku",
    ],
    suitableFor: ["Uzņēmumu svētki", "Konferences un semināri", "Kāzas un banketi", "Festivāli"],
    activities: [
      { title: "Mazuļu stūrītis", description: "Mīkstie moduļi un rotaļlietas bērniem līdz 3 gadiem." },
      { title: "Spēles un rotaļas", description: "Kustību spēles un konkursi animatoru vadībā." },
      { title: "Radošais stūrītis", description: "Zīmēšana, darbnīcas un sejas apgleznošana." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai bērni tiek pieskatīti?", answer: "Jā, bērnu zonā vienmēr ir mūsu animatori. Animatoru skaitu plānojam pēc bērnu skaita un vecuma." },
    ],
    duration: "Visu pasākuma laiku",
    participants: "5–200 bērnu",
    heroImage: "/media/mazulu-sturitis/mazulu-sturitis-01.webp",
    albums: ["mazulu-sturitis", "bauska-taste-2022", "tukuma-rozu-svetki-2025"],
    seasons: ["visu-gadu"],
    sort: 100,
  },
  {
    slug: "animatori-un-teli",
    title: "Animatori un tematiskie tēli",
    icon: "Drama",
    excerpt:
      "Vairāk nekā 45 tēli — no pasaku varoņiem līdz raganām un Ziemassvētku rūķiem — pasākumu vadīšanai un viesu sagaidīšanai.",
    intro:
      "Tematiskie tēli piešķir pasākumam stāstu. Mūsu animatori vada programmas, sagaida viesus, fotografējas ar apmeklētājiem un iesaista bērnus spēlēs.",
    body:
      "Tēlus izvēlamies atbilstoši pasākuma tēmai un sezonai. Varam izveidot arī pilnīgi jaunu tēlu vai stāstu jūsu pasākumam.\n\nAnimatori var strādāt gan uz skatuves, gan starp apmeklētājiem visas dienas garumā.",
    highlights: [
      "45+ tēli un kostīmi",
      "Programmas vadīšana",
      "Viesu sagaidīšana un foto",
      "Iespēja izveidot jaunu tēlu",
    ],
    suitableFor: ["Pilsētu svētki", "Uzņēmumu pasākumi", "Veikalu un centru akcijas", "Skolas un bērnudārzi"],
    activities: [
      { title: "Sagaidīšana", description: "Tēli sagaida viesus un rada noskaņu jau pie ieejas." },
      { title: "Programmas vadīšana", description: "Spēles, konkursi un dejas tēla vadībā." },
      { title: "Foto mirkļi", description: "Fotografēšanās ar tēliem visa pasākuma laikā." },
    ],
    pricingNote: INDIVIDUAL,
    faq: [
      { question: "Vai varat izveidot tēlu mūsu zīmolam?", answer: "Jā, pēc vienošanās izstrādājam tēlu un stāstu tieši jūsu pasākumam." },
    ],
    duration: "1–8 stundas",
    participants: "Neierobežots",
    heroImage: "/media/valpurgu-nakts-tervete-2026/valpurgu-nakts-tervete-2026-10.webp",
    albums: ["valpurgu-nakts-tervete-2026", "vimbu-svetki-2026", "ziemassvetki-2025"],
    seasons: ["ziema", "visu-gadu"],
    sort: 110,
  },
];

export const businessServices: Service[] = drafts.map((d) => ({
  audience: "business",
  pricing: [],
  age: "Visiem vecumiem",
  published: true,
  seoTitle: "",
  seoDescription: "",
  ...d,
}));
