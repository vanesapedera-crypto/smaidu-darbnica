/**
 * Lielformāta spēles (programma "Party Trip", avots: turies.lv/aktivitates/party-trip).
 * `image` — bildes adrese, piem. "/media/speles/jenga.webp" (ja tukšs, kartītē rāda tikai nosaukumu).
 */
export type Game = { name: string; image: string };

export const GAMES: Game[] = [
  { name: "Garās kājas", image: "" },
  { name: "Jenga", image: "" },
  { name: "Katapulta", image: "" },
  { name: "Līdzsvara dēlis", image: "" },
  { name: "Limbo", image: "" },
  { name: "Melnais caurums", image: "" },
  { name: "Slēpes", image: "" },
  { name: "Smaidiņu cope", image: "" },
  { name: "Veiksmīgais loms", image: "" },
  { name: "Pīļuks pa dambi", image: "" },
  { name: "Desas", image: "" },
  { name: "Tornis", image: "" },
  { name: "Saldumu zeme", image: "" },
  { name: "Peļu slazds", image: "" },
  { name: "Slinkais šoferītis", image: "" },
  { name: "Lielformāta smaidiņš", image: "" },
  { name: "Dambrete", image: "" },
  { name: "Acenes", image: "" },
  { name: "Bišu šūniņas", image: "" },
  { name: "Bungas", image: "" },
];
