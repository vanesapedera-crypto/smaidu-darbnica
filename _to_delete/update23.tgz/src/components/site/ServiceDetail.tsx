import { Baby, Check, Clock, Phone, Users } from "lucide-react";
import type { ContactSettings, GalleryImage, Service } from "@/lib/content/types";
import { toReel } from "@/lib/content/media";
import { serviceSchema } from "@/lib/schema";
import InquiryForm from "./InquiryForm";
import JsonLd from "./JsonLd";
import PhotoReel from "./PhotoReel";
import RichText from "./RichText";
import ServiceCard from "./ServiceCard";
import { FaqList } from "./sections";
import { StageHeading, StageHero } from "./stage";
import { ButtonLink, Container, Section } from "./ui";

/**
 * Pakalpojuma / programmas lapa. Viena veidne gan uzņēmumu pakalpojumiem,
 * gan izklaides programmām — atšķiras adrese un aicinājums uz darbību.
 */
export default function ServiceDetail({
  service,
  images,
  related,
  allServices,
  contact,
}: {
  service: Service;
  images: GalleryImage[];
  related: Service[];
  allServices: Service[];
  contact: ContactSettings;
}) {
  const isBusiness = service.audience === "business";
  const base = isBusiness ? "/uznemumiem" : "/izklaides-programmas";
  const path = `${base}/${service.slug}`;
  const ctaHref = isBusiness ? "#pieprasijums" : `/izklaides-programmas/pieteikt?program=${service.slug}`;
  const ctaLabel = isBusiness ? "Pieprasīt piedāvājumu" : "Rezervēt ballīti";
  const phone = isBusiness ? contact.phoneBusiness : contact.phonePrivate;

  const facts = [
    { icon: Clock, label: "Ilgums", value: service.duration },
    { icon: Users, label: "Dalībnieki", value: service.participants },
    { icon: Baby, label: "Vecums", value: service.age },
  ].filter((f) => f.value);
  // Uzņēmumu pakalpojumiem ilgumu un apjomu saskaņo ar katru klientu individuāli
  if (service.audience === "business" && !service.duration && !service.participants) {
    facts.unshift({ icon: Clock, label: "Ilgums un apjoms", value: "Saskaņojam ar jums" });
  }

  // Galvenē: pakalpojuma bilde + divas no tā galerijas
  const heroPhotos = [
    { src: service.heroImage || images[0]?.src, caption: service.title },
    ...images.filter((i) => i.src !== service.heroImage).slice(0, 2).map((i) => ({ src: i.src })),
  ].filter((p): p is { src: string; caption?: string } => Boolean(p.src));

  return (
    <>
      <StageHero
        eyebrow={isBusiness ? "Uzņēmumiem" : "Izklaides programma"}
        title={service.title}
        text={service.excerpt}
        photos={heroPhotos.length ? heroPhotos : [{ src: "/media/smaidu-darbnica/smaidu-darbnica-09.webp" }]}
        crumbs={[
          isBusiness ? { name: "Uzņēmumiem", path: "/uznemumiem" } : { name: "Izklaides programmas", path: "/izklaides-programmas" },
          { name: service.title, path },
        ]}
      >
        <ButtonLink href={ctaHref} size="lg" variant="dark" arrow>
          {ctaLabel}
        </ButtonLink>
      </StageHero>

      {/* Apraksts + galvenie fakti */}
      <Section>
        <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1fr)_380px] lg:gap-20">
          <div>
            {service.intro && (
              <p data-reveal className="text-xl leading-9 font-semibold md:text-2xl md:leading-10">
                {service.intro}
              </p>
            )}
            <div data-reveal className="mt-8">
              <RichText text={service.body} />
            </div>

            {service.highlights.length > 0 && (
              <ul data-reveal className="mt-12 grid gap-3 sm:grid-cols-2">
                {service.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-3 rounded-2xl bg-brand-soft p-4 font-semibold">
                    <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-ink text-brand">
                      <Check className="size-3.5" strokeWidth={3} aria-hidden />
                    </span>
                    {h}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <aside className="lg:sticky lg:top-28 lg:self-start">
            <div className="rotate-1 rounded-[1.75rem] bg-ink p-7 text-white md:p-8">
              {facts.length > 0 && (
                <dl className="space-y-5">
                  {facts.map(({ icon: Icon, label, value }) => (
                    <div key={label} className="flex items-start gap-4">
                      <span className="grid size-10 shrink-0 place-items-center rounded-full bg-brand text-ink">
                        <Icon className="size-4.5" aria-hidden />
                      </span>
                      <div>
                        <dt className="text-sm text-white/60">{label}</dt>
                        <dd className="font-bold">{value}</dd>
                      </div>
                    </div>
                  ))}
                </dl>
              )}
              {service.suitableFor.length > 0 && (
                <div className="mt-7 border-t border-white/10 pt-6">
                  <p className="text-sm text-white/60">Piemērots</p>
                  <ul className="mt-3 flex flex-wrap gap-2">
                    {service.suitableFor.map((s) => (
                      <li key={s} className="rounded-full bg-white/10 px-3 py-1.5 text-sm">
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <ButtonLink href={ctaHref} className="mt-8 w-full" arrow>
                {ctaLabel}
              </ButtonLink>
              <a
                href={`tel:${phone.replace(/\s/g, "")}`}
                className="mt-4 flex items-center justify-center gap-2 text-sm font-semibold text-white/80 hover:text-brand"
              >
                <Phone className="size-4" aria-hidden /> {phone}
              </a>
            </div>
          </aside>
        </Container>
      </Section>

      {/* Programmas gaita — secība ir svarīga, tāpēc soļi ir numurēti */}
      {service.activities.length > 0 && (
        <Section tone="ink">
          <Container>
            <StageHeading light eyebrow={isBusiness ? "Programma" : "Ballītes gaita"} title="Kā tas" highlight="notiek" />
            <ol className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {service.activities.map((a, i) => (
                <li
                  key={a.title}
                  data-reveal
                  style={{ "--reveal-delay": `${(i % 3) * 80}ms` } as React.CSSProperties}
                  className="rounded-[1.5rem] border border-white/10 p-7 transition-colors hover:border-brand/60"
                >
                  <span className="font-display text-4xl font-extrabold text-brand">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="mt-4 text-xl font-extrabold">{a.title}</h3>
                  {a.description && <p className="mt-2 leading-7 text-white/70">{a.description}</p>}
                </li>
              ))}
            </ol>
          </Container>
        </Section>
      )}

      {/* Cenas */}
      {(service.pricing.length > 0 || service.pricingNote) && (
        <Section>
          <Container className="max-w-5xl">
            <StageHeading eyebrow="Cena" title={service.pricing.length ? "Cenas" : "Cik tas"} highlight={service.pricing.length ? undefined : "maksā?"} />
            {service.pricing.length > 0 && (
              <div className="mt-10 grid gap-5 md:grid-cols-2">
                {service.pricing.map((group, gi) => (
                  <div key={group.title} data-reveal className={`rounded-[1.5rem] p-7 ${gi % 2 ? "rotate-1 bg-ink text-white" : "-rotate-1 bg-white ring-1 ring-line"}`}>
                    <h3 className="font-display text-lg font-bold uppercase">{group.title}</h3>
                    <dl className="mt-5 divide-y divide-current/15">
                      {group.options.map((o) => (
                        <div key={o.label} className="flex items-baseline justify-between gap-4 py-3">
                          <dt className="font-medium">{o.label}</dt>
                          <dd className="font-display text-xl font-extrabold whitespace-nowrap">
                            {o.price === null ? "Pēc vienošanās" : `${o.price} €`}
                          </dd>
                        </div>
                      ))}
                    </dl>
                  </div>
                ))}
              </div>
            )}
            {service.pricingNote && (
              <p data-reveal className="mt-8 rounded-2xl bg-surface p-5 leading-7">
                {service.pricingNote}
              </p>
            )}
          </Container>
        </Section>
      )}

      {/* Fotogrāfijas */}
      {images.length > 0 && (
        <section className="overflow-hidden bg-brand-soft pt-20 pb-12 md:pt-28">
          <Container>
            <StageHeading eyebrow="Foto" title="No mūsu" highlight="pasākumiem" />
          </Container>
          <PhotoReel images={toReel(images)} />
        </section>
      )}

      {service.faq.length > 0 && (
        <Section>
          <Container className="max-w-4xl">
            <FaqList items={service.faq} />
          </Container>
        </Section>
      )}

      {/* Pieprasījuma forma uzņēmumiem */}
      {isBusiness && (
        <Section id="pieprasijums" tone="surface" className="scroll-mt-20">
          <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] lg:gap-16">
            <StageHeading
              eyebrow="Pieprasījums"
              title="Pastāstiet par savu"
              highlight="pasākumu"
              text={`Sagatavosim programmu un cenu piedāvājumu: ${service.title.toLowerCase()}.`}
            />
            <InquiryForm services={allServices.map(({ slug, title }) => ({ slug, title }))} defaultService={service.slug} />
          </Container>
        </Section>
      )}

      {related.length > 0 && (
        <Section>
          <Container>
            <StageHeading eyebrow="Jums varētu interesēt" title={isBusiness ? "Citi" : "Citas"} highlight={isBusiness ? "pakalpojumi" : "programmas"} />
            <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((s, i) => (
                <ServiceCard key={s.slug} service={s} href={`${base}/${s.slug}`} index={i} />
              ))}
            </div>
          </Container>
        </Section>
      )}

      <JsonLd data={serviceSchema(service, path)} />
    </>
  );
}
