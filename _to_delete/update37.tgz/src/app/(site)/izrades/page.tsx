import { Check } from "lucide-react";
import VideoShowcase from "@/components/site/VideoShowcase";
import { StageHeading, StageHero } from "@/components/site/stage";
import { ButtonLink, Container, Section } from "@/components/site/ui";
import { getServices, getSettings } from "@/lib/content/queries";
import { pageMetadata } from "@/lib/seo";

export const revalidate = 3600;


export function generateMetadata() {
  return pageMetadata({
    path: "/izrades",
    title: "Izrādes bērniem un ģimenēm",
    description:
      "Interaktīvas Ziemassvētku un tematiskās izrādes uzņēmumu pasākumiem, pašvaldību svētkiem, skolām un bērnudārziem visā Latvijā. Noskatieties video.",
  });
}

export default async function ShowsPage() {
  const [{ shows }, services] = await Promise.all([getSettings(), getServices("business")]);
  // Rezervācija notiek pieprasījuma formā lapā "Kontakti" (ar priekšatlasītu pakalpojumu)
  const slug = services.some((s) => s.slug === "ziemassvetku-pasakumi") ? "ziemassvetku-pasakumi" : "";
  const bookHref = (show?: string) => {
    const q = new URLSearchParams();
    if (slug) q.set("pakalpojums", slug);
    if (show) q.set("izrade", show);
    const qs = q.toString();
    return `/kontakti${qs ? `?${qs}` : ""}#pieprasijums`;
  };

  return (
    <>
      <StageHero
        eyebrow="Izrādes · uzņēmumiem un pašvaldībām"
        title={shows.heroTitle}
        highlight={shows.heroHighlight}
        text={shows.heroText}
        crumbs={[{ name: "Izrādes", path: "/izrades" }]}
        photos={[
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-03.webp", caption: "Ziemassvētku izrāde" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-23.webp", caption: "Rūķi uz skatuves" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-10.webp", caption: "Ziemassvētku izrāde" },
        ]}
      >
        <ButtonLink href="#video" size="lg" arrow>
          Skatīties video
        </ButtonLink>
        <ButtonLink href={bookHref()} size="lg" variant="ghostLight">
          Rezervēt izrādi
        </ButtonLink>
      </StageHero>

      {shows.videos.length > 0 && (
        <Section id="video" className="scroll-mt-20">
          <Container>
            <StageHeading
              eyebrow={`${shows.videos.length} izrādes`}
              title={shows.videosTitle}
              highlight="izrādes"
              text="Noskatieties fragmentus un izvēlieties savam pasākumam piemērotāko."
              className="mb-14 md:mb-20"
            />
            <VideoShowcase videos={shows.videos} bookHref={shows.videos.map((v) => bookHref(v.title))} />
          </Container>
        </Section>
      )}

      {/* Par izrādēm: apraksts + galvenie punkti + kam piemērots (teksti — panelī "Izrādes") */}
      <section className="bg-ink py-20 text-white md:py-28">
        <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)] lg:gap-20">
          <div>
            <StageHeading eyebrow="Par izrādēm" title={shows.aboutTitle} light />
            <div data-reveal className="mt-8 space-y-5 text-lg leading-8 text-white/80">
              {shows.body
                .split(/\n\s*\n/)
                .filter(Boolean)
                .map((para) => (
                  <p key={para.slice(0, 24)}>{para}</p>
                ))}
            </div>
          </div>
          <div data-reveal className="space-y-10">
            {shows.highlights.length > 0 && (
              <ul className="space-y-3">
                {shows.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-3 rounded-2xl bg-white/5 px-5 py-4 font-semibold ring-1 ring-white/10">
                    <Check className="mt-0.5 size-5 shrink-0 text-brand" strokeWidth={3} aria-hidden />
                    {h}
                  </li>
                ))}
              </ul>
            )}
            {shows.suitableFor.length > 0 && (
              <div>
                <p className="mb-4 text-sm font-extrabold tracking-[0.14em] text-brand uppercase">Kam piemērots</p>
                <ul className="flex flex-wrap gap-2">
                  {shows.suitableFor.map((x) => (
                    <li key={x} className="rounded-full bg-white px-4 py-2 text-sm font-bold text-ink">
                      {x}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </Container>
      </section>

    </>
  );
}
