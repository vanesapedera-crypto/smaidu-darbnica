import VideoShowcase from "@/components/site/VideoShowcase";
import { StageHeading, StageHero } from "@/components/site/stage";
import { ButtonLink, Container, Section } from "@/components/site/ui";
import { getServices, getSettings } from "@/lib/content/queries";
import { pageMetadata } from "@/lib/seo";

export const revalidate = 3600;


export function generateMetadata() {
  return pageMetadata({
    path: "/izrades",
    title: "Izrādes bērniem un ģimenēm",
    description:
      "Interaktīvas Ziemassvētku un tematiskās izrādes uzņēmumu pasākumiem, pašvaldību svētkiem, skolām un bērnudārziem visā Latvijā. Noskatieties video.",
  });
}

export default async function ShowsPage() {
  const [{ shows }, services] = await Promise.all([getSettings(), getServices("business")]);
  // Rezervācija notiek pieprasījuma formā lapā "Kontakti" (ar priekšatlasītu pakalpojumu)
  const slug = services.some((s) => s.slug === "ziemassvetku-pasakumi") ? "ziemassvetku-pasakumi" : "";
  const bookHref = (show?: string) => {
    const q = new URLSearchParams();
    if (slug) q.set("pakalpojums", slug);
    if (show) q.set("izrade", show);
    const qs = q.toString();
    return `/kontakti${qs ? `?${qs}` : ""}#pieprasijums`;
  };

  return (
    <>
      <StageHero
        eyebrow="Izrādes · uzņēmumiem un pašvaldībām"
        title={shows.heroTitle}
        highlight={shows.heroHighlight}
        text={shows.heroText}
        crumbs={[{ name: "Izrādes", path: "/izrades" }]}
        photos={[
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-03.webp", caption: "Ziemassvētku izrāde" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-23.webp", caption: "Rūķi uz skatuves" },
          { src: "/media/ziemassvetki-2025/ziemassvetki-2025-10.webp", caption: "Ziemassvētku izrāde" },
        ]}
      >
        <ButtonLink href="#video" size="lg" arrow>
          Skatīties video
        </ButtonLink>
        <ButtonLink href={bookHref()} size="lg" variant="ghostLight">
          Rezervēt izrādi
        </ButtonLink>
      </StageHero>

      {shows.videos.length > 0 && (
        <Section id="video" className="scroll-mt-20">
          <Container>
            <StageHeading
              eyebrow={`${shows.videos.length} izrādes`}
              title={shows.videosTitle}
              highlight="izrādes"
              text="Noskatieties fragmentus un izvēlieties savam pasākumam piemērotāko."
              className="mb-14 md:mb-20"
            />
            <VideoShowcase videos={shows.videos} bookHref={shows.videos.map((v) => bookHref(v.title))} />
          </Container>
        </Section>
      )}

    </>
  );
}
