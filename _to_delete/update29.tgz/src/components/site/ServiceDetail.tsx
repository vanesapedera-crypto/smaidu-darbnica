import { Baby, Check, Clock, Gift, Phone, Users } from "lucide-react";
import type { ContactSettings, GalleryImage, Service } from "@/lib/content/types";
import { toReel } from "@/lib/content/media";
import { serviceSchema } from "@/lib/schema";
import InquiryForm from "./InquiryForm";
import JsonLd from "./JsonLd";
import PhotoReel from "./PhotoReel";
import RichText from "./RichText";
import { PhotoStack, StageHeading, StageHero } from "./stage";
import { ButtonLink, Container, Section } from "./ui";

/**
 * Pakalpojuma / programmas lapa. Viena veidne gan uzņēmumu pakalpojumiem,
 * gan izklaides programmām — atšķiras adrese un aicinājums uz darbību.
 */
export default function ServiceDetail({
  service,
  images,
  allServices,
  contact,
}: {
  service: Service;
  images: GalleryImage[];
  allServices: Service[];
  contact: ContactSettings;
}) {
  const isBusiness = service.audience === "business";
  const base = isBusiness ? "/uznemumiem" : "/izklaides-programmas";
  const path = `${base}/${service.slug}`;
  const ctaHref = isBusiness ? "#pieprasijums" : `/izklaides-programmas/pieteikt?program=${service.slug}`;
  const ctaLabel = isBusiness ? "Pieprasīt piedāvājumu" : "Rezervēt ballīti";
  const phone = isBusiness ? contact.phoneBusiness : contact.phonePrivate;

  const facts = [
    { icon: Clock, label: "Ilgums", value: service.duration },
    { icon: Users, label: "Dalībnieki", value: service.participants },
    { icon: Baby, label: "Vecums", value: service.age },
  ].filter((f) => f.value);
  // Uzņēmumu pakalpojumiem ilgumu un apjomu saskaņo ar katru klientu individuāli
  if (service.audience === "business" && !service.duration && !service.participants) {
    facts.unshift({ icon: Clock, label: "Ilgums un apjoms", value: "Saskaņojam ar jums" });
  }

  // Galvenē: pakalpojuma bilde + divas no tā galerijas
  const heroPhotos = [
    { src: service.heroImage || images[0]?.src, caption: service.title },
    ...images.filter((i) => i.src !== service.heroImage).slice(0, 2).map((i) => ({ src: i.src })),
  ].filter((p): p is { src: string; caption?: string } => Boolean(p.src));

  return (
    <>
      <StageHero
        eyebrow={isBusiness ? "Uzņēmumiem" : "Izklaides programma"}
        title={service.title}
        text={service.excerpt}
        photos={heroPhotos.length ? heroPhotos : [{ src: "/media/smaidu-darbnica/smaidu-darbnica-09.webp" }]}
        crumbs={[
          isBusiness ? { name: "Uzņēmumiem", path: "/uznemumiem" } : { name: "Izklaides programmas", path: "/izklaides-programmas" },
          { name: service.title, path },
        ]}
      >
        <ButtonLink href={ctaHref} size="lg" arrow>
          {ctaLabel}
        </ButtonLink>
      </StageHero>

      {/* Apraksts + galvenie fakti */}
      <Section>
        <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1fr)_380px] lg:gap-20">
          <div>
            {service.intro && (
              <p data-reveal className="text-xl leading-9 font-semibold md:text-2xl md:leading-10">
                {service.intro}
              </p>
            )}
            <div data-reveal className="mt-8">
              <RichText text={service.body} />
            </div>

            {service.highlights.length > 0 && (
              <ul data-reveal className="mt-12 grid gap-3 sm:grid-cols-2">
                {service.highlights.map((h) =>
                  // "🎁 …" — dāvana dalībniekiem, izcelta atsevišķā kartītē
                  h.startsWith("🎁") ? (
                    <li key={h} className="flex items-center gap-4 rounded-2xl bg-brand p-5 sm:col-span-2">
                      <span className="grid size-12 shrink-0 place-items-center rounded-full bg-ink text-brand">
                        <Gift className="size-5" aria-hidden />
                      </span>
                      <span>
                        <span className="block text-xs font-extrabold tracking-[0.12em] uppercase">Dāvanā</span>
                        <span className="text-lg font-extrabold">{h.replace(/^🎁\s*/, "").replace(/^Dāvanā\s*/i, "").replace(/^—\s*/, "")}</span>
                      </span>
                    </li>
                  ) : (
                    <li key={h} className="flex items-start gap-3 rounded-2xl bg-brand-soft p-4 font-semibold">
                      <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-ink text-brand">
                        <Check className="size-3.5" strokeWidth={3} aria-hidden />
                      </span>
                      {h}
                    </li>
                  ),
                )}
              </ul>
            )}
          </div>

          <aside className="lg:sticky lg:top-28 lg:self-start">
            <div className="rotate-1 rounded-[1.75rem] bg-ink p-7 text-white md:p-8">
              {facts.length > 0 && (
                <dl className="space-y-5">
                  {facts.map(({ icon: Icon, label, value }) => (
                    <div key={label} className="flex items-start gap-4">
                      <span className="grid size-10 shrink-0 place-items-center rounded-full bg-brand text-ink">
                        <Icon className="size-4.5" aria-hidden />
                      </span>
                      <div>
                        <dt className="text-sm text-white/60">{label}</dt>
                        <dd className="font-bold">{value}</dd>
                      </div>
                    </div>
                  ))}
                </dl>
              )}
              {/* Cenas (izklaides programmām) — kartītē, lai nebūtu atsevišķas sadaļas */}
              {service.pricing.length > 0 && (
                <div className="mt-7 space-y-5 border-t border-white/10 pt-6">
                  {service.pricing.map((group) => (
                    <div key={group.title}>
                      <p className="text-xs font-extrabold tracking-[0.1em] text-brand uppercase">{group.title}</p>
                      <dl className="mt-2 divide-y divide-white/10">
                        {group.options.map((o) => (
                          <div key={o.label} className="flex items-baseline justify-between gap-4 py-2 text-sm">
                            <dt className="text-white/80">{o.label}</dt>
                            <dd className="font-extrabold whitespace-nowrap">{o.price === null ? "Pēc vienošanās" : `${o.price} €`}</dd>
                          </div>
                        ))}
                      </dl>
                    </div>
                  ))}
                </div>
              )}
              {service.pricingNote && <p className="mt-5 text-sm leading-6 text-white/60">{service.pricingNote}</p>}

              {isBusiness && service.suitableFor.length > 0 && (
                <div className="mt-7 border-t border-white/10 pt-6">
                  <p className="text-sm text-white/60">Piemērots</p>
                  <ul className="mt-3 flex flex-wrap gap-2">
                    {service.suitableFor.map((s) => (
                      <li key={s} className="rounded-full bg-white/10 px-3 py-1.5 text-sm">
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <ButtonLink href={ctaHref} className="mt-8 w-full" arrow>
                {ctaLabel}
              </ButtonLink>
              <a
                href={`tel:${phone.replace(/\s/g, "")}`}
                className="mt-4 flex items-center justify-center gap-2 text-sm font-semibold text-white/80 hover:text-brand"
              >
                <Phone className="size-4" aria-hidden /> {phone}
              </a>
            </div>
          </aside>
        </Container>
      </Section>

      {/* Programmas gaita — secība ir svarīga, tāpēc soļi ir numurēti */}
      {service.activities.length > 0 && (
        <Section tone="ink">
          <Container>
            <StageHeading light eyebrow={isBusiness ? "Programma" : "Ballītes gaita"} title="Kā tas" highlight="notiek" />
            <ol className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {service.activities.map((a, i) => (
                <li
                  key={a.title}
                  data-reveal
                  style={{ "--reveal-delay": `${(i % 3) * 80}ms` } as React.CSSProperties}
                  className="rounded-[1.5rem] border border-white/10 p-7 transition-colors hover:border-brand/60"
                >
                  <span className="font-display text-4xl font-extrabold text-brand">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="mt-4 text-xl font-extrabold">{a.title}</h3>
                  {a.description && <p className="mt-2 leading-7 text-white/70">{a.description}</p>}
                </li>
              ))}
            </ol>
          </Container>
        </Section>
      )}

      {/* Izklaides programmām — fotogrāfijas no ballītēm */}
      {!isBusiness && images.length > 0 && (
        <section className="overflow-hidden bg-surface pt-20 pb-12 md:pt-28">
          <Container>
            <StageHeading eyebrow="Foto" title="No mūsu" highlight="ballītēm" />
          </Container>
          <PhotoReel images={toReel(images)} />
        </section>
      )}

      {/* Uzņēmumiem — pieprasījuma forma kopā ar bildēm (viens bloks, nevis divi) */}
      {isBusiness && (
        <Section id="pieprasijums" tone="surface" className="scroll-mt-20">
          <Container className="grid grid-cols-1 gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)] lg:gap-16">
            <div>
              <StageHeading
                eyebrow="Pieprasījums"
                title="Pastāstiet par savu"
                highlight="pasākumu"
                text={`Sagatavosim programmu un cenu piedāvājumu: ${service.title.toLowerCase()}.`}
              />
              {images.length > 1 && (
                <div className="mt-12 hidden lg:block">
                  <PhotoStack photos={images.slice(1, 3).map((i) => ({ src: i.src }))} />
                </div>
              )}
            </div>
            <InquiryForm services={allServices.map(({ slug, title }) => ({ slug, title }))} defaultService={service.slug} />
          </Container>
        </Section>
      )}

      <JsonLd data={serviceSchema(service, path)} />
    </>
  );
}
