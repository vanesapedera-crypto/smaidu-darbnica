import type { PriceGroup, TitledText } from "../types";

/**
 * Izklaides programmu saturs no esošās smaidudarbnica.lv lapas (2026. gada oktobris).
 * Pārraksta programs-legacy.ts vērtības, kur vecajā lapā informācija ir citāda vai pilnīgāka.
 * Teksti pārņemti no vecās lapas — bez izdomātām detaļām.
 */
type Override = {
  age?: string;
  duration?: string;
  intro?: string;
  body?: string;
  activities?: TitledText[];
  pricing?: PriceGroup[];
  note?: string;
  /** Dāvana / suvenīrs katram dalībniekam (programmas lapā izcelts) */
  gift?: string;
};

const a = (title: string, description = ""): TitledText => ({ title, description });

export const programOverrides: Record<string, Override> = {
  "glitteru-ballite": {
    duration: "2–2,5 stundas (atkarīgs no bērnu skaita)",
    age: "4+ gadi",
    body:
      "Ballīte sākas ar glitteru sejas apgleznošanu un glitteru tetovējumiem, kas rada svētku noskaņu. Bērni saņem krāsainas matu šķipsnas, kas padara katru dalībnieku unikālu.\n\nProgrammā ir radošas un draudzību veicinošas aktivitātes un jautras sacensības, kā arī radošā darbnīca — briļļu meistarklase.",
    gift: "Katram dalībniekam gaismas nūjiņas, lai svētki turpinātos arī mājās",
  },

  "fejas-ballite": {
    duration: "1–1,5 stundas (atkarīgs no bērnu skaita)",
    age: "3+ gadi",
    note: "Izbraukuma ballītēm +10%.",
    body:
      "## Papildu iespējas\n- Virtuļu dekorēšana — 30 €\n- Rokassprādžu gatavošana — 35 €\n- Sejas apgleznošana — 50 €\n- Sausā ledus kokteiļi — 45 €",
  },

  "slaima-meistarklase": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    age: "7+ gadi",
    intro: "Stundu garš radošs piedzīvojums, kur bērni paši gatavo savus krāsainos un spīdīgos slaimus!",
    body:
      "Bērni izvēlas krāsas, spīdumus un dekorācijas, paši sajauc savu slaimu un piedalās jautrās spēlēs. Ballītes noslēgumā katrs slaims tiks iepakots, lai bērns to var paņemt uz mājām.",
  },

  "nerf-ballite": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    age: "7–12 gadi",
    pricing: [
      {
        title: "Ballīte",
        options: [
          { label: "Līdz 15 bērniem", price: 175 },
          { label: "Katrs nākamais bērns", price: 5 },
        ],
      },
    ],
    body:
      "Pirms svarīgajām cīņām dalībnieki iesildās, dod zvērestu un iegūst kamuflāžu, bet pēc tam meklē savus “ieročus”.\n\nBallīte norisinās jūsu izvēlētā vietā — pagalmā, parkā, sporta zālē vai citur visā Latvijā.\n\n**Svarīgi:** ballīte notiek tikai piemērotos laikapstākļos. Lietus un stipra vēja gadījumā pasākums tiek atcelts, jo šādos apstākļos spēle nav tik aizraujoša un kvalitatīva, kā mēs to vēlamies.",
  },

  "wednesday-ballite": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    age: "3–7 gadi",
    activities: [
      a("Drosmes dzira", "Katram dalībniekam īpašā dzira, lai sagatavotos piedzīvojumiem kopā ar Wednesday!"),
      a("Bailes un izaicinājumi", "Kas ir Tavas bailes un kā tās pārvarēt?"),
      a("Baiļu kaste", "Saņem jautru izaicinājumu caur taustes, smaržas un garšas eksperimentiem."),
      a("Skeleti", "Reakcijas spēle."),
      a("Degošā roka", "Piedalies eksperimentā, kas pārbaudīs Tavu drosmi!"),
      a("Kliedziens tumsā!", "Kad gaisma izdziest, tikai kliedzieni būs dzirdami…"),
      a("Nezināmās rokas", "Katram dalībniekam būs iespēja nopelnīt saldumu cimdiņu."),
    ],
    gift: "Katram dalībniekam tematisks tetovējums, lai atcerētos šo neaizmirstamo dzimšanas dienas piedzīvojumu",
  },

  "petnieku-ballite": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    age: "3–7 gadi",
    activities: [
      a("Skaņu, gaismu un lukturīšu efekts", "Sajūti, kā dinozauri atdzīvojas."),
      a("Dinozauru atpazīšanas spēles", "Vai tu proti atšķirt T-rexu no Triceratopsa?"),
      a("Izzinoši stāsti par dinozauriem", "Uzzini par šiem varenajiem dzīvniekiem."),
      a("Fosilijas un kauli", "Saliec savu dinozaura skeletu!"),
      a("Izaudzini savu dinozauru", "Olu meklēšana."),
      a("Mīļākā dinozaura portrets jubilāram"),
      a("Plēsīgie un mierīgie dinozauri", "Sacensības un izaicinājumi!"),
      a("Izkal un izpēti arheologa atradumus"),
    ],
    gift: "Katram dalībniekam tematiskie tetovējumi kā suvenīrs",
  },

  "piratu-ballite": {
    intro: "Ielec piedzīvojumā, kur pārbaudīts tiks ikviens, kurš sevi sauc par īstu pirātu!",
    activities: [
      a("Kapteiņa iecelšana", "Iecelsim kuģa kapteini un dosim tam īstu pirātu vārdu."),
      a("Veiklība un attapība", "Pārbaudīsim katra jaunā pirāta veiklību un attapību."),
      a("Pirātu karte", "Lasīsim pirātu karti un meklēsim labākos maršrutus."),
      a("Pirātu zobeni", "Taisīsim paši savus zobenus, kas tos sargās katrā nākošajā piedzīvojumā."),
      a("Gala pārbaudījums", "Noskaidrosim, vai jaunie pirāti ir gatavi cīņai."),
    ],
    body: "Katrs dalībnieks kļūs par īstu pirātu, kurš ir gatavs iekarot jūras un piedzīvot neaizmirstamu ballīti!",
  },

  "make-up-ballite": {
    duration: "Līdz 3 stundām (atkarīgs no bērnu skaita)",
    age: "10+ gadi",
    pricing: [
      {
        title: "Ballīte Smaidu Darbnīcā",
        options: [
          { label: "Mazā grupa (1–6 bērni)", price: 185 },
          { label: "Vidējā grupa (7–10 bērni)", price: 245 },
          { label: "Lielā grupa (11–15 bērni)", price: 285 },
          { label: "Katrs nākamais bērns", price: 8 },
        ],
      },
      {
        title: "Izbraukuma ballīte",
        options: [
          { label: "Mazā grupa (1–10 bērni)", price: 245 },
          { label: "Lielā grupa (11–15 bērni)", price: 285 },
          { label: "Katrs nākamais bērns", price: 8 },
        ],
      },
    ],
    activities: [
      a("Sejas kopšana", "Pārrunāsim, kā saglabāt seju pēc iespējas veselāku un mirdzošāku."),
      a("Kosmētikas maciņš", "Iepazīsim, kas noteikti jābūt ikvienas meitenes kosmētikas maciņā."),
      a("Otiņas", "Cik daudz un kādas tās ir, un kā pareizi tās lietot?"),
      a("Sejas formas", "Ielūkosimies un mācīsimies atpazīt savu un draudzeņu sejas formu."),
      a("Krāsas", "Krāsas un to nozīme."),
      a("Make-up pirmie soļi", "Praktiska apgūšana."),
      a("Pauze", "Dzēriens un veselīgie našķi."),
    ],
    gift: "Katrai dalībniecei — otiņu komplekts",
  },

  "spa-ballite": {
    duration: "Līdz 3 stundām (atkarīgs no bērnu skaita)",
    age: "6+ gadi",
    gift: "DIY dāvaniņa: cukurskrubju meistarklase no dabīgām izejvielām",
  },

  "eksperimentu-ballite": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    age: "4+ gadi",
    pricing: [
      {
        title: "Ballīte",
        options: [
          { label: "Mazā grupa (1–6 bērni)", price: 195 },
          { label: "Lielā grupa (7–15 bērni)", price: 285 },
          { label: "Katrs nākamais bērns", price: 8 },
        ],
      },
    ],
    activities: [
      a("Magnētu eksperimenti", "Atklāsim noslēpumaino spēku, kas pievelk un atgrūž!"),
      a("Slāpekļa eksperimenti", "Sasaldēsim priekšmetus acu priekšā."),
      a("Krāsu šķidrumu eksperimenti", "Krāsas sajaucas, “sprāgst” un rada īstus zinātnes brīnumus."),
      a("UV gaismas iepazīšana", "Ieraudzīsim slepeno pasauli."),
      a("Eksperimentāls apsveikums jubilāram", "Veidosim nokasāmās kartītes."),
      a("Spēle “Jā vai Nē” par jubilāru", "Jautra iepazīšanās."),
    ],
    body:
      "## Papildu iespējas\n- Saldējuma eksperiments — ~30–40 €\n- Kokteiļu darbnīca — ~10–20 €\n- Tematiski atslēgu piekariņi — 1 € par bērnu",
  },

  "gabbys-dollhouse-ballite": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    activities: [
      a("Tikšanās ar Gabiju", "Tikšanās ar Gabiju pie kakao un iepazīšanās."),
      a("Pirmais noslēpums", "Pārsteiguma kastes atvēršana."),
      a("Ceļojums pa Gabijas māju", "Katrā istabā bērnus gaida jauns pārsteigums, spēle vai aktivitāte."),
      a("Gabijas bingo", "Smiekli skan Gabijas bingo laikā."),
      a("Radošā darbnīca", "Tiek veidotas Gabijas draudzības rokassprādzes."),
      a("Kur paslēpušies kaķīši?", "Bērni dodas jautrā meklēšanā."),
      a("Dāvana gaviļniekam", "Gaviļnieks saņem īpašu dāvanu — mīkstu un mīļu kaķīti."),
    ],
  },

  "frozen-ballite": {
    duration: "60–90 minūtes (atkarīgs no bērnu skaita)",
    activities: [
      a("Karaļvalsts radošās darbnīcas", "Mazās princeses un prinči varēs radīt spožus kronīšus vai zīmēt savas unikālās sniegpārsliņas."),
      a("Ledus rotaļas un ziemas izaicinājumi", "Smiekli un azarts pavadīs bērnus ledus statuju dejās, sniegavīru stafetēs un dzirkstošā dārguma medībā."),
      a("Elzas burvju mirklis", "Kad šķiet, ka pasaka jau ir klāt, Elza parādās ar savu maģisko šovu, pārsteigumiem un siltu stāstu."),
    ],
    gift: "Katram dalībniekam tematiskie tetovējumi kā suvenīrs",
  },

  "putu-ballite": {
    pricing: [
      {
        title: "Ģimenes pasākumi",
        options: [
          { label: "Putu ballīte 30 minūtes", price: 180 },
          { label: "Ceļa izdevumi (€/km)", price: 0.3 },
        ],
      },
      {
        title: "Uzņēmumu un publiskie pasākumi",
        options: [
          { label: "Putu ballīte 60 minūtes (no, + PVN)", price: 400 },
          { label: "Ceļa izdevumi (€/km)", price: 0.3 },
        ],
      },
    ],
    body:
      "**Ģimenes pasākumiem:** 30 minūtes aktīva putu ballīte + kamēr putas izzudīs (kopā ballīte putās līdz 1 h).\n\n**Uzņēmumu un publiskiem pasākumiem:** 60 minūtes aktīva putu ballīte + kamēr putas izzudīs (kopā ballīte putās līdz 1,5 h).",
  },

  "parsteiguma-tels": {
    intro:
      "Vai vēlaties, lai Jūsu pasākums būtu neaizmirstams un pārsteigumu pilns? Pārsteiguma tēls negaidīti ierodas svinībās, izdancina gaviļnieku un fotografējas ar viesiem.",
    body:
      "## Pieejamie tēli\n- Skaja\n- Čeizs\n- Soniks\n- Bings\n- Vienradzis\n- Zaķenīte\n- Rodžers\n- Bēbīši\n\n**Svarīgi:** lielformāta animatori nevada spēles vai citas aktivitātes.",
  },

  "sejas-apgleznosana": {
    body:
      "## Sejas apgleznošana\nBērnu sejiņu apgleznošana piešķir svētkiem krāsas, prieku un neaizmirstamas emocijas. Vienam bērnam — aptuveni 7 minūtes.\n\n## Glittera tetovējumi\nGlittera tetovējumi ir mirdzošs akcents, kas īpaši iecienīts bērnu ballītēs. Tos var apvienot ar sejas apgleznošanu.\n\n## Airbrush tetovējumi\nAirbrush tetovējumi ir moderns un stilīgs risinājums, kas īpaši piemērots lielākiem bērniem un pusaudžiem. Tie ir droši ādai un saglabājas 1–2 dienas. Cena — 4–12 € atkarībā no dizaina izmēra.",
  },
};
