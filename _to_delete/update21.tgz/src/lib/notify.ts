/**
 * E-pasta paziņojums par jaunu pieteikumu (caur Resend REST API — bez papildu bibliotēkām).
 *
 * Vides mainīgie:
 *   RESEND_API_KEY   — atslēga no resend.com (API Keys). Ja nav iestatīta, paziņojums netiek sūtīts.
 *   NOTIFY_EMAIL     — kam sūtīt (noklusējums: smaidudarbnica@gmail.com)
 *   NOTIFY_FROM      — sūtītājs; jābūt Resend apstiprinātā domēnā, piem. "Smaidu Darbnīca <pieteikumi@smaidudarbnica.lv>".
 *                      Kamēr domēns nav apstiprināts, der "onboarding@resend.dev" (sūta tikai uz Resend konta e-pastu).
 *
 * Kļūda e-pasta sūtīšanā nekad neaptur pieteikumu — tas jau ir saglabāts datubāzē un redzams panelī.
 */

type Row = Record<string, unknown>;

const LABELS: [string, string][] = [
  ["company_name", "Uzņēmums"],
  ["parent_name", "Kontaktpersona"],
  ["contact_role", "Amats"],
  ["phone", "Telefons"],
  ["email", "E-pasts"],
  ["service_slug", "Pakalpojums"],
  ["program", "Programma"],
  ["event_type", "Pasākuma veids"],
  ["event_date", "Datums"],
  ["event_time", "Laiks"],
  ["location", "Norises vieta"],
  ["event_city", "Pilsēta / vieta"],
  ["address", "Adrese"],
  ["travel_cost", "Ceļa izdevumi, €"],
  ["travel_km", "Attālums turp un atpakaļ, km"],
  ["participants", "Dalībnieki"],
  ["children_count", "Bērnu skaits"],
  ["child_age", "Bērnu vecums"],
  ["budget_range", "Budžets"],
  ["message", "Ziņojums"],
];

const escape = (v: unknown) =>
  String(v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

export async function notifyNewBooking(row: Row) {
  const key = process.env.RESEND_API_KEY;
  if (!key) return;

  const isBusiness = row.inquiry_type === "business";
  const who = (row.company_name as string) || (row.parent_name as string) || "Jauns pieteikums";
  const subject = `${isBusiness ? "Pieprasījums" : "Rezervācija"}: ${who}${row.event_date ? ` · ${row.event_date}` : ""}`;

  const rows = LABELS.filter(([k]) => row[k] !== null && row[k] !== undefined && row[k] !== "")
    .map(
      ([k, label]) =>
        `<tr><td style="padding:6px 16px 6px 0;color:#7a7268;vertical-align:top;white-space:nowrap">${label}</td><td style="padding:6px 0;white-space:pre-wrap">${escape(row[k])}</td></tr>`,
    )
    .join("");
  const site = process.env.NEXT_PUBLIC_SITE_URL ?? "";
  const html = `<div style="font-family:Arial,sans-serif;font-size:15px;color:#1a1816">
<p style="font-size:18px;margin:0 0 16px"><b>${escape(subject)}</b></p>
<table style="border-collapse:collapse">${rows}</table>
${site ? `<p style="margin-top:24px"><a href="${site}/admin" style="color:#1a1816">Atvērt administrēšanas paneli →</a></p>` : ""}
</div>`;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.NOTIFY_FROM || "Smaidu Darbnīca <onboarding@resend.dev>",
        to: [process.env.NOTIFY_EMAIL || "smaidudarbnica@gmail.com"],
        reply_to: typeof row.email === "string" && row.email ? row.email : undefined,
        subject,
        html,
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) console.error("[notify] Resend", res.status, await res.text());
  } catch (e) {
    console.error("[notify] failed", e);
  }
}
