/**
 * Papildu materiāli uzņēmumu pakalpojumu lapām (pēc pakalpojuma slug):
 *  - SERVICE_PHOTOS — bilžu režģis zem apraksta (faili mapē public/media/<mape>/);
 *  - SERVICE_HERO_VIDEO — YouTube video ID fonam lapas galvenē.
 *
 * Svarīgi: nomainot bildes, failiem jādod JAUNI nosaukumi — pārlūks un Next.js attēlu
 * kešatmiņa vecās bildes ar to pašu nosaukumu rāda vēl ilgi.
 */
const range = (folder: string, prefix: string, count: number) =>
  Array.from({ length: count }, (_, i) => `/media/${folder}/${prefix}-${String(i + 1).padStart(2, "0")}.webp`);

export const SERVICE_PHOTOS: Record<string, string[]> = {
  "pasakumu-organizesana": range("pasakumu-organizesana", "pasakums", 15),
  // 23 bildes (numura 11 nav)
  "sejas-apgleznosana": range("uznemumiem-sejas-apgleznosana", "sejas-apgleznosana", 24).filter((src) => !src.endsWith("-11.webp")),
};

/** Pakalpojumi, kuru bildes ir stāvas (portreta) — režģī rāda augstākas kartītes un 6 kolonnas */
export const SERVICE_PHOTOS_PORTRAIT = new Set(["sejas-apgleznosana"]);

export const SERVICE_HERO_VIDEO: Record<string, string> = {
  "pasakumu-organizesana": "HFTc7zIuO0E",
};
